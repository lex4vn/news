-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: November 29, 2015, 01:17 PM GMT
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `thcsgiaothanh`
--


-- ---------------------------------------


--
-- Table structure for table `gt_authors`
--

DROP TABLE IF EXISTS `gt_authors`;
CREATE TABLE `gt_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_authors`
--

INSERT INTO `gt_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '0e4f76780b37fec237ff4627eefdd721', 1448756904, '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/52.2.98 Chrome/46.2.2490.98 Safari/537.36'), 
(2, 'ckeditor', 3, 'archives,audio,documents,flash,images,video|1|1|1', 'Quản lý', 0, 0, 0, '', 'aed17e9eb6d428e43b979dc8053b8e1c', 1448755480, '::1', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) coc_coc_browser/52.2.98 Chrome/46.2.2490.98 Safari/537.36');


-- ---------------------------------------


--
-- Table structure for table `gt_authors_config`
--

DROP TABLE IF EXISTS `gt_authors_config`;
CREATE TABLE `gt_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_authors_module`
--

DROP TABLE IF EXISTS `gt_authors_module`;
CREATE TABLE `gt_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_authors_module`
--

INSERT INTO `gt_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '1124e6335008707220e19f7c50f5120b'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '5800367ddd2131c2a48abc091b1b4954'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '63df7e6c6e05b0c74053cd5a07e936c4'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, 'ef05a8b7fa5f1c7c5a95506d708f8c67'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '78ad74a0e1e92de06829794cd2333333'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, 'a43b23f38c14ea678873a8c79fd77f8f'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '9b17eb3a34516fe94a82459df04834db'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '8dd0279746a200fd776cbfb7e765ea58'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '2197483829653ac365cdb6315df024ab'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, 'e135387a69d0a8350d84fb428164a186'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, 'ae01670776b268d7263914060c0c0246');


-- ---------------------------------------


--
-- Table structure for table `gt_banip`
--

DROP TABLE IF EXISTS `gt_banip`;
CREATE TABLE `gt_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_banners_click`
--

DROP TABLE IF EXISTS `gt_banners_click`;
CREATE TABLE `gt_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_banners_click`
--

INSERT INTO `gt_banners_click` VALUES
(2, 1448693371, 0, '::1', 'ZZ', '', 'firefox', '', 'Windows 8', 'http://localhost/news/');


-- ---------------------------------------


--
-- Table structure for table `gt_banners_clients`
--

DROP TABLE IF EXISTS `gt_banners_clients`;
CREATE TABLE `gt_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_banners_plans`
--

DROP TABLE IF EXISTS `gt_banners_plans`;
CREATE TABLE `gt_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_banners_plans`
--

INSERT INTO `gt_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1), 
(3, '', 'Quảng cáo phải', '', 'sequential', 180, 200, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_banners_rows`
--

DROP TABLE IF EXISTS `gt_banners_rows`;
CREATE TABLE `gt_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_banners_rows`
--

INSERT INTO `gt_banners_rows` VALUES
(1, 'Sở Giáo dục và Đào tạo Nam Định', 2, 0, 'sgdnd20133229423.jpg', 'jpg', 'image/jpeg', 203, 161, '', '', 'http://namdinh.edu.vn/', '_blank', 1448557801, 1448557801, 0, 0, 1, 3), 
(2, 'Thư viện trực tuyến ViOLET', 2, 0, 'violet20133228530.jpg', 'jpg', 'image/jpeg', 206, 105, '', '', 'http://violet.vn/main/', '_blank', 1448557801, 1448557801, 0, 1, 1, 4), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.png', 'png', 'image/png', 510, 65, '', '', 'http://webnhanh.vn', '_blank', 1448557801, 1448557801, 0, 0, 1, 1), 
(4, 'http&#x3A;&#x002F;&#x002F;ebook.edu.net.vn&#x002F;', 2, 0, 'edu.net20133229025.jpg', 'jpg', 'image/jpeg', 170, 61, '', '', 'http://ebook.edu.net.vn/', '_blank', 1448642504, 1448642504, 0, 0, 1, 2), 
(5, 'http&#x3A;&#x002F;&#x002F;vnptnamdinh.vn&#x002F;', 2, 0, 'vnptnamdinh20139218521.jpg', 'jpg', 'image/jpeg', 398, 168, '', '', 'http://vnptnamdinh.vn/', '_blank', 1448642551, 1448642551, 0, 0, 1, 1), 
(6, 'Những điều chưa biết về thì chuyển cấp', 3, 0, 'trai-5201331215819.jpg', 'jpg', 'image/jpeg', 180, 132, '', '', '', '_blank', 1448726507, 1448726507, 0, 0, 1, 2), 
(7, 'Cuộc thì viết về môi trường xanh', 3, 0, 'trai-12013312145242.jpg', 'jpg', 'image/jpeg', 180, 150, '', '', '', '_blank', 1448726602, 1448726602, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_config`
--

DROP TABLE IF EXISTS `gt_config`;
CREATE TABLE `gt_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_config`
--

INSERT INTO `gt_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '8388608'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '4'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.23'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '5'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'THCS Giao Thanh'), 
('vi', 'global', 'site_logo', ''), 
('vi', 'global', 'site_description', 'Chia sẻ thành công, kết nối đam mê'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'site_theme', 'giaothanh'), 
('vi', 'global', 'mobile_theme', 'mobile_default'), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '1'), 
('vi', 'global', 'upload_logo', ''), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1448803337'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'global', 'ssl_https_modules', ''), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '52'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '0'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('vi', 'siteterms', 'auto_postcomm', '1'), 
('vi', 'siteterms', 'allowed_comm', '-1'), 
('vi', 'siteterms', 'view_comm', '6'), 
('vi', 'siteterms', 'setcomm', '4'), 
('vi', 'siteterms', 'activecomm', '0'), 
('vi', 'siteterms', 'emailcomm', '0'), 
('vi', 'siteterms', 'adminscomm', ''), 
('vi', 'siteterms', 'sortcomm', '0'), 
('vi', 'siteterms', 'captcha', '1'), 
('vi', 'freecontent', 'next_execute', '0'), 
('vi', 'contact', 'bodytext', 'Để không ngừng nâng cao chất lượng dịch vụ và đáp ứng tốt hơn nữa các yêu cầu của Quý khách, chúng tôi mong muốn nhận được các thông tin phản hồi. Nếu Quý khách có bất kỳ thắc mắc hoặc đóng góp nào, xin vui lòng liên hệ với chúng tôi theo thông tin dưới đây. Chúng tôi sẽ phản hồi lại Quý khách trong thời gian sớm nhất.'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'lex4vn@gmail.com'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'lex4vn@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv4c_Vfjjg'), 
('sys', 'global', 'session_prefix', 'nv4s_Eoujfq'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', '5bKI6oD6z43u-XLF6Uc2f-WyiOqA-s-N7vlyxelHNn8,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'video-clip', 'auto_postcomm', '1'), 
('vi', 'video-clip', 'allowed_comm', '-1'), 
('vi', 'video-clip', 'view_comm', '6'), 
('vi', 'video-clip', 'setcomm', '4'), 
('vi', 'video-clip', 'activecomm', '0'), 
('vi', 'video-clip', 'emailcomm', '0'), 
('vi', 'video-clip', 'adminscomm', ''), 
('vi', 'video-clip', 'sortcomm', '0'), 
('vi', 'video-clip', 'captcha', '1'), 
('vi', 'tra-cuu-diem-thi', 'auto_postcomm', '1'), 
('vi', 'tra-cuu-diem-thi', 'allowed_comm', '-1'), 
('vi', 'tra-cuu-diem-thi', 'view_comm', '6'), 
('vi', 'tra-cuu-diem-thi', 'setcomm', '4'), 
('vi', 'tra-cuu-diem-thi', 'activecomm', '1'), 
('vi', 'tra-cuu-diem-thi', 'emailcomm', '0'), 
('vi', 'tra-cuu-diem-thi', 'adminscomm', ''), 
('vi', 'tra-cuu-diem-thi', 'sortcomm', '0'), 
('vi', 'tra-cuu-diem-thi', 'captcha', '1');


-- ---------------------------------------


--
-- Table structure for table `gt_cookies`
--

DROP TABLE IF EXISTS `gt_cookies`;
CREATE TABLE `gt_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_cookies`
--

INSERT INTO `gt_cookies` VALUES
('nv3c_vndjsc_ctr', 'NzEyMjk3NjQ1LlZO', '.api.nukeviet.vn', '/', 1480102722, 0), 
('nv3c_vndjsc_u_lang', '3KI,', '.api.nukeviet.vn', '/', 1480102722, 0), 
('nv3c_vndjsc_nvvithemever', 'yg,,', '.api.nukeviet.vn', '/', 1480102722, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_counter`
--

DROP TABLE IF EXISTS `gt_counter`;
CREATE TABLE `gt_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_counter`
--

INSERT INTO `gt_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1448803035, 0), 
('total', 'hits', 1448803035, 42, 42), 
('year', '2015', 1448803035, 42, 42), 
('year', '2016', 0, 0, 0), 
('year', '2017', 0, 0, 0), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('month', 'Jan', 0, 0, 0), 
('month', 'Feb', 0, 0, 0), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 0, 0, 0), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 0, 0, 0), 
('month', 'Nov', 1448803035, 42, 42), 
('month', 'Dec', 0, 0, 0), 
('day', '01', 0, 0, 0), 
('day', '02', 0, 0, 0), 
('day', '03', 0, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 0, 0, 0), 
('day', '07', 0, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 0, 0, 0), 
('day', '10', 0, 0, 0), 
('day', '11', 0, 0, 0), 
('day', '12', 0, 0, 0), 
('day', '13', 0, 0, 0), 
('day', '14', 0, 0, 0), 
('day', '15', 0, 0, 0), 
('day', '16', 0, 0, 0), 
('day', '17', 0, 0, 0), 
('day', '18', 0, 0, 0), 
('day', '19', 0, 0, 0), 
('day', '20', 0, 0, 0), 
('day', '21', 0, 0, 0), 
('day', '22', 0, 0, 0), 
('day', '23', 0, 0, 0), 
('day', '24', 0, 0, 0), 
('day', '25', 0, 0, 0), 
('day', '26', 0, 0, 0), 
('day', '27', 1448642582, 14, 14), 
('day', '28', 1448728125, 11, 11), 
('day', '29', 1448803035, 17, 17), 
('day', '30', 0, 0, 0), 
('day', '31', 0, 0, 0), 
('dayofweek', 'Sunday', 1448803035, 17, 17), 
('dayofweek', 'Monday', 0, 0, 0), 
('dayofweek', 'Tuesday', 0, 0, 0), 
('dayofweek', 'Wednesday', 0, 0, 0), 
('dayofweek', 'Thursday', 0, 0, 0), 
('dayofweek', 'Friday', 1448642582, 14, 14), 
('dayofweek', 'Saturday', 1448728125, 11, 11), 
('hour', '00', 1448732192, 2, 2), 
('hour', '01', 1448735796, 2, 2), 
('hour', '02', 1448739399, 2, 2), 
('hour', '03', 1448743004, 2, 2), 
('hour', '04', 1448746607, 2, 2), 
('hour', '05', 1448750211, 2, 2), 
('hour', '06', 1448754131, 2, 2), 
('hour', '07', 1448756881, 2, 2), 
('hour', '08', 0, 0, 0), 
('hour', '09', 0, 0, 0), 
('hour', '10', 0, 0, 0), 
('hour', '11', 0, 0, 0), 
('hour', '12', 0, 0, 0), 
('hour', '13', 1448693313, 0, 0), 
('hour', '14', 1448697058, 0, 0), 
('hour', '15', 1448700957, 0, 0), 
('hour', '16', 1448702763, 0, 0), 
('hour', '17', 1448707465, 0, 0), 
('hour', '18', 0, 0, 0), 
('hour', '19', 0, 0, 0), 
('hour', '20', 1448803035, 1, 1), 
('hour', '21', 1448634599, 0, 0), 
('hour', '22', 1448726150, 0, 0), 
('hour', '23', 1448728125, 0, 0), 
('bot', 'googlebot', 0, 0, 0), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 0, 0, 0), 
('browser', 'edge', 0, 0, 0), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1448803035, 37, 37), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 0, 0, 0), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 0, 0, 0), 
('browser', 'iphone', 0, 0, 0), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1448756881, 5, 5), 
('browser', 'android', 0, 0, 0), 
('browser', 'googlebot', 0, 0, 0), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 0, 0, 0), 
('browser', 'Unspecified', 0, 0, 0), 
('os', 'unknown', 0, 0, 0), 
('os', 'win', 0, 0, 0), 
('os', 'win10', 0, 0, 0), 
('os', 'win8', 1448803035, 42, 42), 
('os', 'win7', 0, 0, 0), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 0, 0, 0), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 0, 0, 0), 
('os', 'linux', 0, 0, 0), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 0, 0, 0), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 0, 0, 0), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('os', 'Unspecified', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 0, 0, 0), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 0, 0, 0), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 0, 0, 0), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 0, 0, 0), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1448803035, 42, 42), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_cronjobs`
--

DROP TABLE IF EXISTS `gt_cronjobs`;
CREATE TABLE `gt_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_cronjobs`
--

INSERT INTO `gt_cronjobs` VALUES
(1, 1448557801, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1448803037, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1448557801, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1448691302, 1, 'Tự động lưu CSDL'), 
(3, 1448557801, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1448755640, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1448557801, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1448759031, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1448557801, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1448691302, 1, 'Xóa các file error_log quá hạn'), 
(6, 1448557801, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1448557801, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1448755640, 1, 'Xóa các referer quá hạn'), 
(8, 1448557801, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1448692098, 1, 'Cập nhật đánh giá site từ các máy chủ tìm kiếm'), 
(9, 1448557801, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1448755640, 1, 'Kiểm tra phiên bản NukeViet'), 
(10, 1448557801, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1448692098, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `gt_extension_files`
--

DROP TABLE IF EXISTS `gt_extension_files`;
CREATE TABLE `gt_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_googleplus`
--

DROP TABLE IF EXISTS `gt_googleplus`;
CREATE TABLE `gt_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_groups`
--

DROP TABLE IF EXISTS `gt_groups`;
CREATE TABLE `gt_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_groups`
--

INSERT INTO `gt_groups` VALUES
(1, 'Super admin', 'Super Admin', '', 1448557801, 0, 0, 1, 1, 0, 1, 0), 
(2, 'General admin', 'General Admin', '', 1448557801, 0, 0, 2, 1, 0, 0, 0), 
(3, 'Module admin', 'Module Admin', '', 1448557801, 0, 0, 3, 1, 0, 1, 0), 
(4, 'Users', 'Users', '', 1448557801, 0, 0, 4, 1, 0, 2, 0), 
(5, 'Guest', 'Guest', '', 1448557801, 0, 0, 5, 1, 0, 0, 0), 
(6, 'All', 'All', '', 1448557801, 0, 0, 6, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_groups_users`
--

DROP TABLE IF EXISTS `gt_groups_users`;
CREATE TABLE `gt_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_groups_users`
--

INSERT INTO `gt_groups_users` VALUES
(1, 1, '0'), 
(3, 2, '0');


-- ---------------------------------------


--
-- Table structure for table `gt_language`
--

DROP TABLE IF EXISTS `gt_language`;
CREATE TABLE `gt_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_language_file`
--

DROP TABLE IF EXISTS `gt_language_file`;
CREATE TABLE `gt_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_logs`
--

DROP TABLE IF EXISTS `gt_logs`;
CREATE TABLE `gt_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=109  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_logs`
--

INSERT INTO `gt_logs` VALUES
(1, 'vi', 'login', '[lex4vn@gmail.com] Đăng nhập', ' Client IP:::1', '', 0, 1448557959), 
(2, 'vi', 'themes', 'Thiết lập giao diện theme: \"giaothanh\"', '', '', 1, 1448558540), 
(3, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1448558905), 
(4, 'vi', 'themes', 'Kích hoạt theme: \"giaothanh\"', '', '', 1, 1448558968), 
(5, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1448558991), 
(6, 'vi', 'themes', 'Kích hoạt theme: \"giaothanh\"', '', '', 1, 1448559007), 
(7, 'vi', 'themes', 'Kích hoạt theme: \"default\"', '', '', 1, 1448559012), 
(8, 'vi', 'themes', 'Kích hoạt theme: \"giaothanh\"', '', '', 1, 1448559014), 
(9, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448559804), 
(10, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448559869), 
(11, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448559892), 
(12, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448559950), 
(13, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448560013), 
(14, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448560043), 
(15, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448560080), 
(16, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448560341), 
(17, 'vi', 'themes', 'Thiết lập layout theme: \"giaothanh\"', '', '', 1, 1448561912), 
(18, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1448562112), 
(19, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1448562277), 
(20, 'vi', 'login', '[lex4vn] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1448566428), 
(21, 'vi', 'login', '[lex4vn] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1448566437), 
(22, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1448566442), 
(23, 'vi', 'menu', 'delete menu id: 2', 'Trang chur', '', 1, 1448566544), 
(24, 'vi', 'modules', 'Thêm module ảo video_clip', '', '', 1, 1448566782), 
(25, 'vi', 'modules', 'Thiết lập module mới video-clip', '', '', 1, 1448566798), 
(26, 'vi', 'modules', 'Sửa module &ldquo;video-clip&rdquo;', '', '', 1, 1448566824), 
(27, 'vi', 'themes', 'Thêm block', 'Name : Video clip', '', 1, 1448566933), 
(28, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448567148), 
(29, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448567351), 
(30, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448567425), 
(31, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448567524), 
(32, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448567781), 
(33, 'vi', 'themes', 'Sửa block', 'Name : Chủ đề', '', 1, 1448632466), 
(34, 'vi', 'themes', 'Sửa block', 'Name : Module Menu', '', 1, 1448632486), 
(35, 'vi', 'themes', 'Sửa block', 'Name : Video clip', '', 1, 1448632499), 
(36, 'vi', 'modules', 'Thêm module ảo tra_cuu_diem_thi', '', '', 1, 1448632777), 
(37, 'vi', 'modules', 'Thiết lập module mới tra-cuu-diem-thi', '', '', 1, 1448632786), 
(38, 'vi', 'modules', 'Sửa module &ldquo;tra-cuu-diem-thi&rdquo;', '', '', 1, 1448632913), 
(39, 'vi', 'modules', 'Sửa module &ldquo;tra-cuu-diem-thi&rdquo;', '', '', 1, 1448632937), 
(40, 'vi', 'tra-cuu-diem-thi', 'Add', ' ', '', 1, 1448633054), 
(41, 'vi', 'themes', 'Thêm block', 'Name : global html', '', 1, 1448633135), 
(42, 'vi', 'themes', 'Sửa block', 'Name : global html', '', 1, 1448633260), 
(43, 'vi', 'themes', 'Sửa block', 'Name : Tra cứu điểm thi', '', 1, 1448633284), 
(44, 'vi', 'themes', 'Sửa block', 'Name : Tra cứu điểm thi', '', 1, 1448633395), 
(45, 'vi', 'themes', 'Thêm block', 'Name : Tin tiêu điểm', '', 1, 1448633524), 
(46, 'vi', 'themes', 'Sửa block', 'Name : Tin tiêu điểm', '', 1, 1448633775), 
(47, 'vi', 'themes', 'Sửa block', 'Name : Tin tiêu điểm', '', 1, 1448633856), 
(48, 'vi', 'themes', 'Sửa block', 'Name : Trang chủ', '', 1, 1448634044), 
(49, 'vi', 'themes', 'Sửa block', 'Name : Trang chủ', '', 1, 1448634106), 
(50, 'vi', 'themes', 'Thêm block', 'Name : module block news', '', 1, 1448641917), 
(51, 'vi', 'themes', 'Sửa block', 'Name : module block news', '', 1, 1448641964), 
(52, 'vi', 'banners', 'log_edit_banner', 'bannerid 1', '', 1, 1448642122), 
(53, 'vi', 'banners', 'log_edit_banner', 'bannerid 2', '', 1, 1448642299), 
(54, 'vi', 'banners', 'log_add_banner', 'bannerid 4', '', 1, 1448642504), 
(55, 'vi', 'banners', 'log_add_banner', 'bannerid 5', '', 1, 1448642551), 
(56, 'vi', 'banners', 'log_edit_banner', 'bannerid 5', '', 1, 1448642574), 
(57, 'vi', 'themes', 'Thêm block', 'Name : Liên kết hữu ích', '', 1, 1448642713), 
(58, 'vi', 'themes', 'Sửa block', 'Name : Liên kết hữu ích', '', 1, 1448642764), 
(59, 'vi', 'themes', 'Sửa block', 'Name : Liên kết hữu ích', '', 1, 1448642976), 
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1448694297), 
(61, 'vi', 'themes', 'Thêm block', 'Name : global bootstrap', '', 1, 1448694388), 
(62, 'vi', 'themes', 'Sửa block', 'Name : global bootstrap', '', 1, 1448694412), 
(63, 'vi', 'themes', 'Sửa block', 'Name : global bootstrap', '', 1, 1448694447), 
(64, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1448695990), 
(65, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1448696055), 
(66, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1448696209), 
(67, 'vi', 'themes', 'Sửa block', 'Name : global menu footer', '', 1, 1448697206), 
(68, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1448698767), 
(69, 'vi', 'themes', 'Sửa block', 'Name : Số người truy cập', '', 1, 1448698982), 
(70, 'vi', 'themes', 'Sửa block', 'Name : module block news', '', 1, 1448700374), 
(71, 'vi', 'themes', 'Sửa block', 'Name : module block news', '', 1, 1448700559), 
(72, 'vi', 'themes', 'Thêm block', 'Name : global banners', '', 1, 1448726404), 
(73, 'vi', 'banners', 'log_add_plan', 'planid 3', '', 1, 1448726440), 
(74, 'vi', 'banners', 'log_add_banner', 'bannerid 6', '', 1, 1448726507), 
(75, 'vi', 'themes', 'Sửa block', 'Name : global banners', '', 1, 1448726538), 
(76, 'vi', 'banners', 'log_add_banner', 'bannerid 7', '', 1, 1448726602), 
(77, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1448726688), 
(78, 'vi', 'banners', 'log_edit_plan', 'planid 3', '', 1, 1448726754), 
(79, 'vi', 'themes', 'Sửa block', 'Name : Liên kết hữu ích', '', 1, 1448727371), 
(80, 'vi', 'modules', 'Thêm module ảo nha_truong', '', '', 1, 1448727519), 
(81, 'vi', 'modules', 'Thiết lập module mới nha-truong', '', '', 1, 1448727542), 
(82, 'vi', 'nha-truong', 'Thêm chuyên mục', 'Giới thiệu', '', 1, 1448727804), 
(83, 'vi', 'upload', 'Upload file', 'uploads/news/2015_11/20-11.png', '', 1, 1448753286), 
(84, 'vi', 'modules', 'Xóa module \"nha-truong\"', '', '', 1, 1448753674), 
(85, 'vi', 'news', 'Thêm chuyên mục', 'Tin học', '', 1, 1448754041), 
(86, 'vi', 'news', 'Thêm chuyên mục', 'Thư viện', '', 1, 1448754071), 
(87, 'vi', 'news', 'Thêm chuyên mục', 'Thời khóa biểu', '', 1, 1448754095), 
(88, 'vi', 'news', 'Thêm chuyên mục', 'Chung tay', '', 1, 1448754111), 
(89, 'vi', 'news', 'log_del_source', 'NukeViet', '', 1, 1448754517), 
(90, 'vi', 'news', 'log_del_source', 'VINADES.,JSC', '', 1, 1448754522), 
(91, 'vi', 'users', 'Xóa nhóm', 'group_id: 10', '', 1, 1448754688), 
(92, 'vi', 'users', 'Xóa nhóm', 'group_id: 11', '', 1, 1448754696), 
(93, 'vi', 'users', 'Xóa nhóm', 'group_id: 12', '', 1, 1448754702), 
(94, 'vi', 'users', 'log_add_user', 'userid 2', '', 1, 1448754855), 
(95, 'vi', 'authors', 'Thêm Quản trị', 'Username: quanly', '', 1, 1448755130), 
(96, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1448755145), 
(97, 'vi', 'login', '[quanly] Đăng nhập', ' Client IP:::1', '', 0, 1448755174), 
(98, 'vi', 'login', '[lex4vn] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1448755333), 
(99, 'vi', 'login', '[lex4vn] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1448755336), 
(100, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1448755345), 
(101, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: quanly', '', 1, 1448755424), 
(102, 'vi', 'login', '[quanly] Đăng nhập', ' Client IP:::1', '', 0, 1448755480), 
(103, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: quanly', '', 1, 1448755531), 
(104, 'vi', 'authors', 'Sửa thông tin Quản trị website', 'Username: quanly', '', 1, 1448755559), 
(105, 'vi', 'news', 'Xóa bài viêt', 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam, Công bố dự án NukeViet 3.0 sau 1 tháng ra mắt VINADES.,JSC, Giới thiệu về mã nguồn mở NukeViet, Thư mời hợp tác liên kết quảng cáo và cung cấp hosting thử nghiệm, Tuyển dụng lập trình viên, chuyên viên đồ họa phát triển NukeViet, Webnhanh.vn - website dịch vụ chuyên nghiệp cho NukeViet chính thức ra mắt, NukeViet - Công cụ mã nguồn mở cho cộng đồng thiết kế website Việt Nam, Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011', '', 2, 1448755582), 
(106, 'vi', 'news', 'Thêm chuyên mục', 'Chào cờ', '', 2, 1448755679), 
(107, 'vi', 'login', '[quanly] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1448756875), 
(108, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1448756904);


-- ---------------------------------------


--
-- Table structure for table `gt_notification`
--

DROP TABLE IF EXISTS `gt_notification`;
CREATE TABLE `gt_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3) NOT NULL,
  `module` varchar(50) NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_plugin`
--

DROP TABLE IF EXISTS `gt_plugin`;
CREATE TABLE `gt_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_sessions`
--

DROP TABLE IF EXISTS `gt_sessions`;
CREATE TABLE `gt_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_sessions`
--

INSERT INTO `gt_sessions` VALUES
('p3bgbenmovk4l71r1tak6sup22', 0, 'guest', 1448803035);


-- ---------------------------------------


--
-- Table structure for table `gt_setup`
--

DROP TABLE IF EXISTS `gt_setup`;
CREATE TABLE `gt_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_setup_extensions`
--

DROP TABLE IF EXISTS `gt_setup_extensions`;
CREATE TABLE `gt_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_setup_extensions`
--

INSERT INTO `gt_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'giaothanh', 0, 0, 'giaothanh', 'giaothanh', '4.0.0 1448559584', 1448559584, 'VINADES.,JSC', 'Đây là giao diện mặc định của hệ thống. Bạn không được xóa, đổi tên và không nên sửa trực tiếp vào giao diện này. Nếu muốn, hãy copy thành giao diện khác và kích hoạt sử dụng giao diện mới đó để chỉnh sửa và sử dụng.'), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'default', 0, 0, 'default', 'default', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.21 1436199600', 1448557801, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'video-clip', 0, 0, 'page', 'video_clip', '', 1448566782, '', ''), 
(0, 'module', 'tra-cuu-diem-thi', 0, 0, 'page', 'tra_cuu_diem_thi', '', 1448632777, '', '');


-- ---------------------------------------


--
-- Table structure for table `gt_setup_language`
--

DROP TABLE IF EXISTS `gt_setup_language`;
CREATE TABLE `gt_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_setup_language`
--

INSERT INTO `gt_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `gt_upload_dir`
--

DROP TABLE IF EXISTS `gt_upload_dir`;
CREATE TABLE `gt_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=21  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_upload_dir`
--

INSERT INTO `gt_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads', 0, 0, 0, 0, 0), 
(2, 'uploads/about', 0, 0, 0, 0, 0), 
(3, 'uploads/banners', 0, 0, 0, 0, 0), 
(4, 'uploads/contact', 0, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 0, 0, 0, 0, 0), 
(6, 'uploads/menu', 1448566603, 0, 0, 0, 0), 
(7, 'uploads/news', 0, 0, 0, 0, 0), 
(8, 'uploads/news/source', 0, 0, 0, 0, 0), 
(9, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(10, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(11, 'uploads/page', 0, 0, 0, 0, 0), 
(12, 'uploads/siteterms', 0, 0, 0, 0, 0), 
(13, 'uploads/users', 0, 0, 0, 0, 0), 
(14, 'uploads/video-clip', 0, 0, 0, 0, 0), 
(15, 'uploads/tra-cuu-diem-thi', 0, 0, 0, 0, 0), 
(20, 'uploads/news/2015_11', 1448753177, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_upload_file`
--

DROP TABLE IF EXISTS `gt_upload_file`;
CREATE TABLE `gt_upload_file` (
  `name` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_upload_file`
--

INSERT INTO `gt_upload_file` VALUES
('20-11.png', 'png', 'image', 872654, 'assets/news/2015_11/20-11.png', 80, 40, '855|426', 1, 1448753288, 20, '20-11.png', '20 11');


-- ---------------------------------------


--
-- Table structure for table `gt_users`
--

DROP TABLE IF EXISTS `gt_users`;
CREATE TABLE `gt_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40) DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_users`
--

INSERT INTO `gt_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}CFXCgEOtvQW54eMQe5OrtHBV4j9DR1FF', 'lex4vn@gmail.com', 'admin', '', '', '', 0, '', 1448557950, 'THCSGIAOTHANH', '2015', '', 0, 1, '', 1, '', 1448557950, '', '', '', 0, 0, ''), 
(2, 'quanly', '76ce09fc04225228897e61087b1172a8', '{SSHA}SOuUlbxS2YoXkX91y4T5gi0NaSNVUm1N', 'lex4vn1@gmail.com', 'quanly', '', '', '', 0, '', 1448754855, 'quan ly la gi', 'quan ly', '', 0, 1, '', 1, '', 0, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `gt_users_config`
--

DROP TABLE IF EXISTS `gt_users_config`;
CREATE TABLE `gt_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_users_config`
--

INSERT INTO `gt_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|12345678|123456789|1234567890|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman', 1448557801), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1448557801), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1448557801), 
('avatar_width', '80', 1448557801), 
('avatar_height', '80', 1448557801), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `gt_users_field`
--

DROP TABLE IF EXISTS `gt_users_field`;
CREATE TABLE `gt_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_users_info`
--

DROP TABLE IF EXISTS `gt_users_info`;
CREATE TABLE `gt_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_users_info`
--

INSERT INTO `gt_users_info` VALUES
(1), 
(2);


-- ---------------------------------------


--
-- Table structure for table `gt_users_openid`
--

DROP TABLE IF EXISTS `gt_users_openid`;
CREATE TABLE `gt_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_users_question`
--

DROP TABLE IF EXISTS `gt_users_question`;
CREATE TABLE `gt_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_users_question`
--

INSERT INTO `gt_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `gt_users_reg`
--

DROP TABLE IF EXISTS `gt_users_reg`;
CREATE TABLE `gt_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  `openid_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_about`
--

DROP TABLE IF EXISTS `gt_vi_about`;
CREATE TABLE `gt_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_about`
--

INSERT INTO `gt_vi_about` VALUES
(1, 'Giới thiệu về NukeViet 3.0', 'Gioi-thieu-ve-NukeViet-3-0', '', '', '', '<p> NukeViet 3.0 là thế hệ CMS hoàn toàn mới do người Việt phát triển. Lần đầu tiên ở Việt Nam, một bộ nhân mã nguồn mở được đầu tư bài bản và chuyên nghiệp cả về tài chính, nhân lực và thời gian. Kết quả là 100% dòng code của NukeViet được viết mới hoàn toàn, NukeViet 3 sử dụng xHTML, CSS với Xtemplate và jquery cho phép vận dụng Ajax uyển chuyển cả trong công nghệ nhân.</p><p> Tận dụng các thành tựu mã nguồn mở có sẵn nhưng NukeViet 3 vẫn đảm bảo rằng từng dòng code là được code tay (NukeViet 3 không sử dụng bất cứ một nền tảng (framework) nào). Điều này có nghĩa là NukeViet 3 hoàn toàn không phụ thuộc vào bất cứ framework nào trong quá trình phát triển của mình; Bạn hoàn toàn có thể đọc hiểu để tự lập trình trên NukeViet 3 nếu bạn biết PHP và MySQL (đồng nghĩa với việc NukeViet 3 hoàn toàn mở và dễ nghiên cứu cho bất cứ ai muốn tìm hiểu về code của NukeViet).</p><p style=\"text-align: justify;\"> Bộ nhân NukeViet 3 ngoài việc thừa hưởng sự đơn giản vốn có của NukeViet nhưng không vì thế mà quên nâng cấp mình. Hệ thống NukeViet 3 hỗ trợ công nghệ đa nhân module. Chúng tôi gọi đó là công nghệ ảo hóa module. Công nghệ này cho phép người sử dụng có thể khởi tạo hàng ngàn module một cách tự động mà không cần động đến một dòng code. Các module được sinh ra từ công nghệ này gọi là module ảo. Module ảo là module được nhân bản từ một module bất kỳ của hệ thống nukeviet nếu module đó cho phép tạo module ảo.</p><p style=\"text-align: justify;\"> NukeViet 3 cũng hỗ trợ việc cài đặt từ động 100% các module, block, theme từ Admin Control Panel, người sử dụng có thể cài module mà không cần làm bất cứ thao tác phức tạp nào. NukeViet 3 còn cho phép bạn đóng gói module để chia sẻ cho người khác.</p><p style=\"text-align: justify;\"> NukeViet 3 đa ngôn ngữ 100% với 2 loại: đa ngôn ngữ giao diện và đa ngôn ngữ database. NukeViet 3 có tính năng&nbsp; cho phép người quản trị tự xây dựng ngôn ngữ mới cho site. Cho&nbsp; phép đóng gói file ngôn ngữ để chia sẻ cho cộng đồng... câu chuyện về nukeviet 3 sẽ còn dài vì một loạt các tính năng cao cấp vẫn đang được phát triển. Hãy sử dụng và phổ biến NukeViet 3 để tự mình tận hưởng những thành quả mới nhất từ công nghệ web mã nguồn mở. Cuối cùng NukeViet 3 là món của của <a href=\"http://vinades.vn\" target=\"_blank\">VINADES.,JSC</a> gửi tới cộng đồng để cảm ơn cộng đồng đã ủng hộ thời gian qua, bây giờ NukeViet 3 được đưa trở lại cộng đồng để cộng đồng tiếp tục nuôi nấng và chăm sóc NukeViet lớn mạnh hơn.</p><p style=\"text-align: justify;\"> Mọi ý kiến và yêu cầu trợ giúp về NukeViet 3 các bạn có thể gửi lên diễn đàn NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn/phpbb/\" target=\"_blank\">http://nukeviet.vn/phpbb/</a>. Việc giúp đỡ hoàn toàn miễn phí và mọi góp ý của bạn đều được hoan nghênh.</p> <div style=\"text-align: center;\"><iframe width=\"420\" height=\"315\" src=\"https://www.youtube.com/embed/dG66RocXSeY?rel=0&amp;showinfo=0\" frameborder=\"0\" allowfullscreen></iframe>	<br /> Video clip Giới thiệu mã nguồn mở NukeViet trong bản tin Tiêu điểm của chương trình Xã hội thông tin<br /> (Đài truyền hình kỹ thuật số VTC) phát sóng lúc 20h chủ nhật, ngày 05-09-2010 trên VTC1</div>', '', 0, '4', '', 0, 1, 1, 1275320174, 1275320174, 1), 
(2, 'Giới thiệu về công ty chuyên quản NukeViet', 'Gioi-thieu-ve-cong-ty-chuyen-quan-NukeViet', '', '', '', '<p style=\"text-align: justify;\"> <strong>Công ty cổ phần phát triển nguồn mở Việt Nam</strong> (VINADES.,JSC) là công ty mã nguồn mở đầu tiên của Việt Nam sở hữu riêng một mã nguồn mở nổi tiếng và đang được sử dụng ở hàng ngàn website lớn nhỏ trong mọi lĩnh vực.<br /> <br /> Ra đời từ hoạt động của tổ chức nguồn mở NukeViet (từ năm 2004) và chính thức được thành lập đầu 2010 tại Hà Nội, khi đó báo chí đã gọi VINADES.,JSC là &quot;Công ty mã nguồn mở đầu tiên tại Việt Nam&quot;.<br /> <br /> Ngay sau khi thành lập, VINADES.,JSC đã thành công trong việc xây dựng <strong><a href=\"http://nukeviet.vn/\" target=\"_blank\">NukeViet</a></strong> thành một <a href=\"http://nukeviet.vn/\" target=\"_blank\">mã nguồn mở</a> thuần Việt. Với khả năng mạnh mẽ, cùng các ưu điểm vượt trội về công nghệ, độ an toàn và bảo mật, NukeViet đã được hàng ngàn website lựa chọn sử dụng trong năm qua. Ngay khi ra mắt phiên bản mới năm 2010, NukeViet đã tạo nên hiệu ứng truyền thông chưa từng có trong lịch sử mã nguồn mở Việt Nam. Tiếp đó, năm 2011 Mã nguồn mở NukeViet đã giành giải thưởng Nhân tài đất Việt cho sản phẩm Công nghệ thông tin đã được ứng dụng rộng rãi.<br /></p><div style=\"text-align: center;\"><iframe width=\"420\" height=\"315\" src=\"https://www.youtube.com/embed/ZOhu2bLE-eA?rel=0&amp;showinfo=0\" frameborder=\"0\" allowfullscreen></iframe><br /> <strong>Video clip trao giải Nhân tài đất Việt 2011.</strong><br /> Sản phẩm &quot;Mã nguồn mở NukeViet&quot; đã nhận giải cao nhất (Giải ba, không có giải nhất, giải nhì) của Giải thưởng Nhân Tài Đất Việt 2011 ở lĩnh vực Công nghệ thông tin - Sản phẩm đã có ứng dụng rộng rãi.</div><p style=\"text-align: justify;\"><br /> Tự chuyên nghiệp hóa mình, thoát khỏi mô hình phát triển tự phát, công ty đã nỗ lực vươn mình ra thế giới và đang phấn đấu trở thành một trong những hiện tượng của thời &quot;dotcom&quot; ở Việt Nam.<br /> <br /> Để phục vụ hoạt động của công ty, công ty liên tục mở rộng và tuyển thêm nhân sự ở các vị trí: Lập trình viên, chuyên viên đồ họa, nhân viên kinh doanh... Hãy liên hệ ngay để gia nhập VINADES.,JSC và cùng chúng tôi trở thành một công ty phát triển nguồn mở thành công nhất Việt Nam.</p> <p>Nếu bạn có nhu cầu triển khai các hệ thống <a href=\"http://toasoandientu.vn\" target=\"_blank\">Tòa Soạn Điện Tử</a>, <a href=\"http://webnhanh.vn\" target=\"_blank\">phần mềm trực tuyến</a>, <a href=\"http://vinades.vn\" target=\"_blank\">thiết kế web</a> theo yêu cầu hoặc dịch vụ có liên quan, hãy liên hệ công ty chuyên quản NukeViet theo thông tin dưới đây:</p><p><strong><span style=\"font-family: Tahoma; color: rgb(255, 69, 0); font-size: 14px;\">CÔNG TY CỔ PHẦN PHÁT TRIỂN NGUỒN MỞ VIỆT NAM</span></strong><br /> <strong>VIET NAM OPEN SOURCE DEVELOPMENT JOINT STOCK COMPANY</strong> (<strong>VINADES.,JSC</strong>)<br />Website: <a href=\"http://vinades.vn/\">http://vinades.vn</a> | <a href=\"http://nukeviet.vn/\">http://nukeviet.vn</a> | <a href=\"http://webnhanh.vn/\">http://webnhanh.vn</a><br />Trụ sở: Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội.<br /> - Tel: +84-4-85872007<br /> - Fax: +84-4-35500914<br /> - Email: <a href=\"mailto:contact@vinades.vn\">contact@vinades.vn</a></p>', '', 0, '4', '', 0, 2, 1, 1275320224, 1275320224, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_about_config`
--

DROP TABLE IF EXISTS `gt_vi_about_config`;
CREATE TABLE `gt_vi_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_about_config`
--

INSERT INTO `gt_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_blocks_groups`
--

DROP TABLE IF EXISTS `gt_vi_blocks_groups`;
CREATE TABLE `gt_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10) DEFAULT '1',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=53  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_blocks_groups`
--

INSERT INTO `gt_vi_blocks_groups` VALUES
(1, 'default', 'news', 'module.block_newscenter.php', 'Tin mới nhất', '', 'no_title', '[TOP]', 0, '1', '6', 0, 1, 'a:9:{s:6:\"numrow\";i:5;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:12:\"length_title\";i:400;s:15:\"length_hometext\";i:0;s:5:\"width\";i:500;s:6:\"height\";i:0;s:7:\"nocatid\";a:0:{}}'), 
(2, 'default', 'banners', 'global.banners.php', 'Quảng cáo giữa trang', '', 'no_title', '[TOP]', 0, '1', '6', 0, 2, 'a:1:{s:12:\"idplanbanner\";i:1;}'), 
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', '6', 0, 2, ''), 
(5, 'default', 'banners', 'global.banners.php', 'Quảng cáo trái', '', 'no_title', '[LEFT]', 0, '1', '6', 1, 3, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(6, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'border', '[RIGHT]', 0, '1', '6', 1, 1, ''), 
(7, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', 'primary', '[RIGHT]', 0, '1', '6', 1, 2, ''), 
(8, 'default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:44:\"/news/index.php?language=vi&amp;nv=siteterms\";}'), 
(9, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 2, ''), 
(10, 'default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[QR_CODE]', 0, '1', '6', 1, 1, 'a:3:{s:5:\"level\";s:1:\"M\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(11, 'default', 'statistics', 'global.counter_button.php', 'Online button', '', 'no_title', '[QR_CODE]', 0, '1', '6', 1, 2, ''), 
(12, 'default', 'users', 'global.user_button.php', 'Đăng nhập thành viên', '', 'no_title', '[PERSONALAREA]', 0, '1', '6', 1, 1, ''), 
(13, 'default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'simple', '[COMPANY_INFO]', 0, '1', '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.9845159999999992805896908976137638092041015625;s:20:\"company_mapcenterlng\";d:105.7954749999999961573848850093781948089599609375;s:14:\"company_maplat\";d:20.9845159999999992805896908976137638092041015625;s:14:\"company_maplng\";d:105.7954750000000103682396002113819122314453125;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(14, 'default', 'menu', 'global.bootstrap.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(15, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', '6', 1, 1, ''), 
(16, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(17, 'default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'simple', '[MENU_FOOTER]', 0, '1', '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:8:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";}}'), 
(18, 'default', 'freecontent', 'global.free_content.php', 'Sản phẩm', '', 'no_title', '[FEATURED_PRODUCT]', 0, '1', '6', 1, 1, 'a:2:{s:7:\"blockid\";i:1;s:7:\"numrows\";i:2;}'), 
(19, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(20, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 2, ''), 
(21, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 1, ''), 
(22, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 2, ''), 
(23, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(24, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(25, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:35:\"/index.php?language=vi&nv=siteterms\";}'), 
(26, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(27, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.9845159999999992805896908976137638092041015625;s:20:\"company_mapcenterlng\";d:105.7954749999999961573848850093781948089599609375;s:14:\"company_maplat\";d:20.9845159999999992805896908976137638092041015625;s:14:\"company_maplng\";d:105.7954750000000103682396002113819122314453125;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(28, 'giaothanh', 'theme', 'global.company_info.php', 'global company info', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 1, 'a:17:{s:12:\"company_name\";s:98:\"Bản quyền Website thuộc về Trường Trung học cơ sở Giao Thanh - Tỉnh Nam Định.\";s:16:\"company_sortname\";s:0:\"\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:20:\"Nam Định, Vietnam\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.2791504392019987790263257920742034912109375;s:20:\"company_mapcenterlng\";d:106.2055624660199981690311687998473644256591796875;s:14:\"company_maplat\";d:20.279180400000001327498466707766056060791015625;s:14:\"company_maplng\";d:106.2051483999999845764250494539737701416015625;s:15:\"company_mapzoom\";i:20;s:13:\"company_phone\";s:72:\"+84-4-85872007&#91;+84485872007&#93;|+84-904762534&#91;+84904762534&#93;\";s:11:\"company_fax\";s:0:\"\";s:13:\"company_email\";s:27:\"lienhe@thcsgiaothanh.edu.vn\";s:15:\"company_website\";s:20:\"thcsgiaothanh.edu.vn\";}'), 
(29, 'giaothanh', 'contact', 'global.contact_default.php', 'Contact Default', NULL, 'no_title', '[CONTACT_DEFAULT]', 0, '1', '6', 1, 1, ''), 
(33, 'giaothanh', 'menu', 'global.metismenu.php', 'Trang chủ', '/news', 'primary', '[LEFT]', 0, '1', '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:20;}'), 
(35, 'giaothanh', 'banners', 'global.banners.php', 'Quảng cáo trái', NULL, 'no_title', '[LEFT]', 0, '1', '6', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:2;}'), 
(36, 'giaothanh', 'theme', 'global.menu_footer.php', 'global menu footer', '', 'no_title', '[MENU_FOOTER]', 0, '1', '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:8:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";}}'), 
(38, 'giaothanh', 'users', 'global.user_button.php', 'Đăng nhập thành viên', NULL, 'no_title', '[PERSONALAREA]', 0, '1', '6', 1, 1, ''), 
(40, 'giaothanh', 'statistics', 'global.counter.php', 'Số người truy cập', '', 'primary', '[LEFT]', 0, '1', '6', 1, 4, ''), 
(43, 'giaothanh', 'theme', 'global.social.php', 'Social icon', NULL, 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 1, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(44, 'giaothanh', 'news', 'module.block_newscenter.php', 'Tin mới nhất', NULL, 'no_title', '[TOP]', 0, '1', '6', 0, 1, 'a:5:{s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:5:\"width\";s:3:\"400\";s:6:\"height\";s:0:\"\";}'), 
(46, 'giaothanh', 'video-clip', 'global.html.php', 'Video clip', 'video-clip', 'primary', '[RIGHT]', 0, '1', '6', 1, 2, 'a:1:{s:11:\"htmlcontent\";s:86:\"<object data=\"http://www.youtube.com/v/dEE-VrJiLOk\" height=\"120\" width=\"180\"></object>\";}'), 
(47, 'giaothanh', 'tra-cuu-diem-thi', 'global.html.php', 'Tra cứu điểm thi', '', 'primary', '[RIGHT]', 0, '1', '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:125:\"<div class=\"input-group-search\"><div class=\"input-group-btn-search\"><em class=\"fa fa-search fa-md\">Tra cứu</em></div></div>\";}'), 
(48, 'giaothanh', 'news', 'global.block_groups.php', 'Tin tiêu điểm', '/news/groups/Tin-tieu-diem/', 'primary', '[RIGHT]', 0, '1', '6', 1, 3, 'a:5:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:5;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(49, 'giaothanh', 'news', 'module.block_topline.php', 'module block news', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 0, 1, 'a:4:{s:6:\"numrow\";i:0;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:3:\"top\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(50, 'giaothanh', 'page', 'global.html.php', 'Liên kết hữu ích', '', 'primary', '[LEFT]', 0, '1', '6', 1, 3, 'a:1:{s:11:\"htmlcontent\";s:63:\"<a href=\"http://vnexpress.net/\">Báo điện tử VnExpress</a>\";}'), 
(52, 'giaothanh', 'banners', 'global.banners.php', 'global banners', '', 'no_title', '[RIGHT]', 0, '1', '6', 1, 4, 'a:1:{s:12:\"idplanbanner\";i:3;}');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_blocks_weight`
--

DROP TABLE IF EXISTS `gt_vi_blocks_weight`;
CREATE TABLE `gt_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_blocks_weight`
--

INSERT INTO `gt_vi_blocks_weight` VALUES
(13, 1, 1), 
(13, 36, 1), 
(13, 37, 1), 
(13, 38, 1), 
(13, 39, 1), 
(13, 45, 1), 
(13, 46, 1), 
(13, 47, 1), 
(13, 48, 1), 
(13, 55, 1), 
(13, 58, 1), 
(13, 4, 1), 
(13, 5, 1), 
(13, 6, 1), 
(13, 7, 1), 
(13, 8, 1), 
(13, 9, 1), 
(13, 10, 1), 
(13, 11, 1), 
(13, 12, 1), 
(13, 49, 1), 
(13, 57, 1), 
(13, 52, 1), 
(13, 53, 1), 
(13, 29, 1), 
(13, 30, 1), 
(13, 31, 1), 
(13, 32, 1), 
(13, 33, 1), 
(13, 34, 1), 
(13, 35, 1), 
(13, 18, 1), 
(13, 19, 1), 
(13, 20, 1), 
(13, 21, 1), 
(13, 22, 1), 
(13, 23, 1), 
(13, 24, 1), 
(13, 25, 1), 
(13, 26, 1), 
(13, 27, 1), 
(13, 56, 1), 
(15, 1, 1), 
(15, 36, 1), 
(15, 37, 1), 
(15, 38, 1), 
(15, 39, 1), 
(15, 45, 1), 
(15, 46, 1), 
(15, 47, 1), 
(15, 48, 1), 
(15, 55, 1), 
(15, 58, 1), 
(15, 4, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 8, 1), 
(15, 9, 1), 
(15, 10, 1), 
(15, 11, 1), 
(15, 12, 1), 
(15, 49, 1), 
(15, 57, 1), 
(15, 52, 1), 
(15, 53, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 35, 1), 
(15, 18, 1), 
(15, 19, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 22, 1), 
(15, 23, 1), 
(15, 24, 1), 
(15, 25, 1), 
(15, 26, 1), 
(15, 27, 1), 
(15, 56, 1), 
(18, 1, 1), 
(18, 36, 1), 
(18, 37, 1), 
(18, 38, 1), 
(18, 39, 1), 
(18, 45, 1), 
(18, 46, 1), 
(18, 47, 1), 
(18, 48, 1), 
(18, 55, 1), 
(18, 58, 1), 
(18, 4, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 8, 1), 
(18, 9, 1), 
(18, 10, 1), 
(18, 11, 1), 
(18, 12, 1), 
(18, 49, 1), 
(18, 57, 1), 
(18, 52, 1), 
(18, 53, 1), 
(18, 29, 1), 
(18, 30, 1), 
(18, 31, 1), 
(18, 32, 1), 
(18, 33, 1), 
(18, 34, 1), 
(18, 35, 1), 
(18, 18, 1), 
(18, 19, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 22, 1), 
(18, 23, 1), 
(18, 24, 1), 
(18, 25, 1), 
(18, 26, 1), 
(18, 27, 1), 
(18, 56, 1), 
(8, 1, 1), 
(8, 36, 1), 
(8, 37, 1), 
(8, 38, 1), 
(8, 39, 1), 
(8, 45, 1), 
(8, 46, 1), 
(8, 47, 1), 
(8, 48, 1), 
(8, 55, 1), 
(8, 58, 1), 
(8, 4, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 1), 
(8, 8, 1), 
(8, 9, 1), 
(8, 10, 1), 
(8, 11, 1), 
(8, 12, 1), 
(8, 49, 1), 
(8, 57, 1), 
(8, 52, 1), 
(8, 53, 1), 
(8, 29, 1), 
(8, 30, 1), 
(8, 31, 1), 
(8, 32, 1), 
(8, 33, 1), 
(8, 34, 1), 
(8, 35, 1), 
(8, 18, 1), 
(8, 19, 1), 
(8, 20, 1), 
(8, 21, 1), 
(8, 22, 1), 
(8, 23, 1), 
(8, 24, 1), 
(8, 25, 1), 
(8, 26, 1), 
(8, 27, 1), 
(8, 56, 1), 
(9, 1, 2), 
(9, 36, 2), 
(9, 37, 2), 
(9, 38, 2), 
(9, 39, 2), 
(9, 45, 2), 
(9, 46, 2), 
(9, 47, 2), 
(9, 48, 2), 
(9, 55, 2), 
(9, 58, 2), 
(9, 4, 2), 
(9, 5, 2), 
(9, 6, 2), 
(9, 7, 2), 
(9, 8, 2), 
(9, 9, 2), 
(9, 10, 2), 
(9, 11, 2), 
(9, 12, 2), 
(9, 49, 2), 
(9, 57, 2), 
(9, 52, 2), 
(9, 53, 2), 
(9, 29, 2), 
(9, 30, 2), 
(9, 31, 2), 
(9, 32, 2), 
(9, 33, 2), 
(9, 34, 2), 
(9, 35, 2), 
(9, 18, 2), 
(9, 19, 2), 
(9, 20, 2), 
(9, 21, 2), 
(9, 22, 2), 
(9, 23, 2), 
(9, 24, 2), 
(9, 25, 2), 
(9, 26, 2), 
(9, 27, 2), 
(9, 56, 2), 
(3, 7, 1), 
(3, 8, 1), 
(3, 4, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 6, 1), 
(3, 5, 1), 
(3, 12, 1), 
(3, 9, 1), 
(4, 22, 1), 
(4, 24, 1), 
(4, 19, 1), 
(4, 27, 1), 
(4, 23, 1), 
(4, 21, 1), 
(4, 18, 1), 
(4, 20, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 34, 1), 
(4, 32, 1), 
(4, 31, 1), 
(4, 33, 1), 
(4, 30, 1), 
(4, 29, 1), 
(4, 35, 1), 
(5, 1, 1), 
(5, 36, 1), 
(5, 37, 1), 
(5, 38, 1), 
(5, 39, 1), 
(5, 45, 1), 
(5, 46, 1), 
(5, 47, 1), 
(5, 48, 1), 
(5, 55, 1), 
(5, 58, 1), 
(5, 4, 2), 
(5, 5, 2), 
(5, 6, 2), 
(5, 7, 2), 
(5, 8, 2), 
(5, 9, 2), 
(5, 10, 2), 
(5, 11, 2), 
(5, 12, 2), 
(5, 49, 1), 
(5, 57, 1), 
(5, 52, 1), 
(5, 53, 1), 
(5, 29, 2), 
(5, 30, 2), 
(5, 31, 2), 
(5, 32, 2), 
(5, 33, 2), 
(5, 34, 2), 
(5, 35, 2), 
(5, 18, 2), 
(5, 19, 2), 
(5, 20, 2), 
(5, 21, 2), 
(5, 22, 2), 
(5, 23, 2), 
(5, 24, 2), 
(5, 25, 2), 
(5, 26, 2), 
(5, 27, 2), 
(5, 56, 1), 
(17, 1, 1), 
(17, 36, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 45, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 55, 1), 
(17, 58, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 49, 1), 
(17, 57, 1), 
(17, 52, 1), 
(17, 53, 1), 
(17, 29, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 56, 1), 
(14, 1, 1), 
(14, 36, 1), 
(14, 37, 1), 
(14, 38, 1), 
(14, 39, 1), 
(14, 45, 1), 
(14, 46, 1), 
(14, 47, 1), 
(14, 48, 1), 
(14, 55, 1), 
(14, 58, 1), 
(14, 4, 1), 
(14, 5, 1), 
(14, 6, 1), 
(14, 7, 1), 
(14, 8, 1), 
(14, 9, 1), 
(14, 10, 1), 
(14, 11, 1), 
(14, 12, 1), 
(14, 49, 1), 
(14, 57, 1), 
(14, 52, 1), 
(14, 53, 1), 
(14, 29, 1), 
(14, 30, 1), 
(14, 31, 1), 
(14, 32, 1), 
(14, 33, 1), 
(14, 34, 1), 
(14, 35, 1), 
(14, 18, 1), 
(14, 19, 1), 
(14, 20, 1), 
(14, 21, 1), 
(14, 22, 1), 
(14, 23, 1), 
(14, 24, 1), 
(14, 25, 1), 
(14, 26, 1), 
(14, 27, 1), 
(14, 56, 1), 
(12, 1, 1), 
(12, 36, 1), 
(12, 37, 1), 
(12, 38, 1), 
(12, 39, 1), 
(12, 45, 1), 
(12, 46, 1), 
(12, 47, 1), 
(12, 48, 1), 
(12, 55, 1), 
(12, 58, 1), 
(12, 4, 1), 
(12, 5, 1), 
(12, 6, 1), 
(12, 7, 1), 
(12, 8, 1), 
(12, 9, 1), 
(12, 10, 1), 
(12, 11, 1), 
(12, 12, 1), 
(12, 49, 1), 
(12, 57, 1), 
(12, 52, 1), 
(12, 53, 1), 
(12, 29, 1), 
(12, 30, 1), 
(12, 31, 1), 
(12, 32, 1), 
(12, 33, 1), 
(12, 34, 1), 
(12, 35, 1), 
(12, 18, 1), 
(12, 19, 1), 
(12, 20, 1), 
(12, 21, 1), 
(12, 22, 1), 
(12, 23, 1), 
(12, 24, 1), 
(12, 25, 1), 
(12, 26, 1), 
(12, 27, 1), 
(12, 56, 1), 
(10, 1, 1), 
(10, 36, 1), 
(10, 37, 1), 
(10, 38, 1), 
(10, 39, 1), 
(10, 45, 1), 
(10, 46, 1), 
(10, 47, 1), 
(10, 48, 1), 
(10, 55, 1), 
(10, 58, 1), 
(10, 4, 1), 
(10, 5, 1), 
(10, 6, 1), 
(10, 7, 1), 
(10, 8, 1), 
(10, 9, 1), 
(10, 10, 1), 
(10, 11, 1), 
(10, 12, 1), 
(10, 49, 1), 
(10, 57, 1), 
(10, 52, 1), 
(10, 53, 1), 
(10, 29, 1), 
(10, 30, 1), 
(10, 31, 1), 
(10, 32, 1), 
(10, 33, 1), 
(10, 34, 1), 
(10, 35, 1), 
(10, 18, 1), 
(10, 19, 1), 
(10, 20, 1), 
(10, 21, 1), 
(10, 22, 1), 
(10, 23, 1), 
(10, 24, 1), 
(10, 25, 1), 
(10, 26, 1), 
(10, 27, 1), 
(10, 56, 1), 
(11, 1, 2), 
(11, 36, 2), 
(11, 37, 2), 
(11, 38, 2), 
(11, 39, 2), 
(11, 45, 2), 
(11, 46, 2), 
(11, 47, 2), 
(11, 48, 2), 
(11, 55, 2), 
(11, 58, 2), 
(11, 4, 2), 
(11, 5, 2), 
(11, 6, 2), 
(11, 7, 2), 
(11, 8, 2), 
(11, 9, 2), 
(11, 10, 2), 
(11, 11, 2), 
(11, 12, 2), 
(11, 49, 2), 
(11, 57, 2), 
(11, 52, 2), 
(11, 53, 2), 
(11, 29, 2), 
(11, 30, 2), 
(11, 31, 2), 
(11, 32, 2), 
(11, 33, 2), 
(11, 34, 2), 
(11, 35, 2), 
(11, 18, 2), 
(11, 19, 2), 
(11, 20, 2), 
(11, 21, 2), 
(11, 22, 2), 
(11, 23, 2), 
(11, 24, 2), 
(11, 25, 2), 
(11, 26, 2), 
(11, 27, 2), 
(11, 56, 2), 
(6, 1, 1), 
(6, 36, 1), 
(6, 37, 1), 
(6, 38, 1), 
(6, 39, 1), 
(6, 45, 1), 
(6, 46, 1), 
(6, 47, 1), 
(6, 48, 1), 
(6, 55, 1), 
(6, 58, 1), 
(6, 4, 1), 
(6, 5, 1), 
(6, 6, 1), 
(6, 7, 1), 
(6, 8, 1), 
(6, 9, 1), 
(6, 10, 1), 
(6, 11, 1), 
(6, 12, 1), 
(6, 49, 1), 
(6, 57, 1), 
(6, 52, 1), 
(6, 53, 1), 
(6, 29, 1), 
(6, 30, 1), 
(6, 31, 1), 
(6, 32, 1), 
(6, 33, 1), 
(6, 34, 1), 
(6, 35, 1), 
(6, 18, 1), 
(6, 19, 1), 
(6, 20, 1), 
(6, 21, 1), 
(6, 22, 1), 
(6, 23, 1), 
(6, 24, 1), 
(6, 25, 1), 
(6, 26, 1), 
(6, 27, 1), 
(6, 56, 1), 
(7, 1, 2), 
(7, 36, 2), 
(7, 37, 2), 
(7, 38, 2), 
(7, 39, 2), 
(7, 45, 2), 
(7, 46, 2), 
(7, 47, 2), 
(7, 48, 2), 
(7, 55, 2), 
(7, 58, 2), 
(7, 4, 2), 
(7, 5, 2), 
(7, 6, 2), 
(7, 7, 2), 
(7, 8, 2), 
(7, 9, 2), 
(7, 10, 2), 
(7, 11, 2), 
(7, 12, 2), 
(7, 49, 2), 
(7, 57, 2), 
(7, 52, 2), 
(7, 53, 2), 
(7, 29, 2), 
(7, 30, 2), 
(7, 31, 2), 
(7, 32, 2), 
(7, 33, 2), 
(7, 34, 2), 
(7, 35, 2), 
(7, 18, 2), 
(7, 19, 2), 
(7, 20, 2), 
(7, 21, 2), 
(7, 22, 2), 
(7, 23, 2), 
(7, 24, 2), 
(7, 25, 2), 
(7, 26, 2), 
(7, 27, 2), 
(7, 56, 2), 
(16, 1, 1), 
(16, 36, 1), 
(16, 37, 1), 
(16, 38, 1), 
(16, 39, 1), 
(16, 45, 1), 
(16, 46, 1), 
(16, 47, 1), 
(16, 48, 1), 
(16, 55, 1), 
(16, 58, 1), 
(16, 4, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 8, 1), 
(16, 9, 1), 
(16, 10, 1), 
(16, 11, 1), 
(16, 12, 1), 
(16, 49, 1), 
(16, 57, 1), 
(16, 52, 1), 
(16, 53, 1), 
(16, 29, 1), 
(16, 30, 1), 
(16, 31, 1), 
(16, 32, 1), 
(16, 33, 1), 
(16, 34, 1), 
(16, 35, 1), 
(16, 18, 1), 
(16, 19, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 22, 1), 
(16, 23, 1), 
(16, 24, 1), 
(16, 25, 1), 
(16, 26, 1), 
(16, 27, 1), 
(16, 56, 1), 
(1, 4, 1), 
(2, 4, 2), 
(27, 1, 1), 
(27, 36, 1), 
(27, 37, 1), 
(27, 38, 1), 
(27, 39, 1), 
(27, 45, 1), 
(27, 46, 1), 
(27, 47, 1), 
(27, 48, 1), 
(27, 55, 1), 
(27, 58, 1), 
(27, 4, 1), 
(27, 5, 1), 
(27, 6, 1), 
(27, 7, 1), 
(27, 8, 1), 
(27, 9, 1), 
(27, 10, 1), 
(27, 11, 1), 
(27, 12, 1), 
(27, 49, 1), 
(27, 57, 1), 
(27, 52, 1), 
(27, 53, 1), 
(27, 29, 1), 
(27, 30, 1), 
(27, 31, 1), 
(27, 32, 1), 
(27, 33, 1), 
(27, 34, 1), 
(27, 35, 1), 
(27, 18, 1), 
(27, 19, 1), 
(27, 20, 1), 
(27, 21, 1), 
(27, 22, 1), 
(27, 23, 1), 
(27, 24, 1), 
(27, 25, 1), 
(27, 26, 1), 
(27, 27, 1), 
(27, 56, 1), 
(25, 1, 1), 
(25, 36, 1), 
(25, 37, 1), 
(25, 38, 1), 
(25, 39, 1), 
(25, 45, 1), 
(25, 46, 1), 
(25, 47, 1), 
(25, 48, 1), 
(25, 55, 1), 
(25, 58, 1), 
(25, 4, 1), 
(25, 5, 1), 
(25, 6, 1), 
(25, 7, 1), 
(25, 8, 1), 
(25, 9, 1), 
(25, 10, 1), 
(25, 11, 1), 
(25, 12, 1), 
(25, 49, 1), 
(25, 57, 1), 
(25, 52, 1), 
(25, 53, 1), 
(25, 29, 1), 
(25, 30, 1), 
(25, 31, 1), 
(25, 32, 1), 
(25, 33, 1), 
(25, 34, 1), 
(25, 35, 1), 
(25, 18, 1), 
(25, 19, 1), 
(25, 20, 1), 
(25, 21, 1), 
(25, 22, 1), 
(25, 23, 1), 
(25, 24, 1), 
(25, 25, 1), 
(25, 26, 1), 
(25, 27, 1), 
(25, 56, 1), 
(26, 1, 1), 
(26, 36, 1), 
(26, 37, 1), 
(26, 38, 1), 
(26, 39, 1), 
(26, 45, 1), 
(26, 46, 1), 
(26, 47, 1), 
(26, 48, 1), 
(26, 55, 1), 
(26, 58, 1), 
(26, 4, 1), 
(26, 5, 1), 
(26, 6, 1), 
(26, 7, 1), 
(26, 8, 1), 
(26, 9, 1), 
(26, 10, 1), 
(26, 11, 1), 
(26, 12, 1), 
(26, 49, 1), 
(26, 57, 1), 
(26, 52, 1), 
(26, 53, 1), 
(26, 29, 1), 
(26, 30, 1), 
(26, 31, 1), 
(26, 32, 1), 
(26, 33, 1), 
(26, 34, 1), 
(26, 35, 1), 
(26, 18, 1), 
(26, 19, 1), 
(26, 20, 1), 
(26, 21, 1), 
(26, 22, 1), 
(26, 23, 1), 
(26, 24, 1), 
(26, 25, 1), 
(26, 26, 1), 
(26, 27, 1), 
(26, 56, 1), 
(19, 1, 1), 
(19, 36, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 45, 1), 
(19, 46, 1), 
(19, 47, 1), 
(19, 48, 1), 
(19, 55, 1), 
(19, 58, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 49, 1), 
(19, 57, 1), 
(19, 52, 1), 
(19, 53, 1), 
(19, 29, 1), 
(19, 30, 1), 
(19, 31, 1), 
(19, 32, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 18, 1), 
(19, 19, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 56, 1), 
(20, 1, 2), 
(20, 36, 2), 
(20, 37, 2), 
(20, 38, 2), 
(20, 39, 2), 
(20, 45, 2), 
(20, 46, 2), 
(20, 47, 2), 
(20, 48, 2), 
(20, 55, 2), 
(20, 58, 2), 
(20, 4, 2), 
(20, 5, 2), 
(20, 6, 2), 
(20, 7, 2), 
(20, 8, 2), 
(20, 9, 2), 
(20, 10, 2), 
(20, 11, 2), 
(20, 12, 2), 
(20, 49, 2), 
(20, 57, 2), 
(20, 52, 2), 
(20, 53, 2), 
(20, 29, 2), 
(20, 30, 2), 
(20, 31, 2), 
(20, 32, 2), 
(20, 33, 2), 
(20, 34, 2), 
(20, 35, 2), 
(20, 18, 2), 
(20, 19, 2), 
(20, 20, 2), 
(20, 21, 2), 
(20, 22, 2), 
(20, 23, 2), 
(20, 24, 2), 
(20, 25, 2), 
(20, 26, 2), 
(20, 27, 2), 
(20, 56, 2), 
(21, 1, 1), 
(21, 36, 1), 
(21, 37, 1), 
(21, 38, 1), 
(21, 39, 1), 
(21, 45, 1), 
(21, 46, 1), 
(21, 47, 1), 
(21, 48, 1), 
(21, 55, 1), 
(21, 58, 1), 
(21, 4, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 8, 1), 
(21, 9, 1), 
(21, 10, 1), 
(21, 11, 1), 
(21, 12, 1), 
(21, 49, 1), 
(21, 57, 1), 
(21, 52, 1), 
(21, 53, 1), 
(21, 29, 1), 
(21, 30, 1), 
(21, 31, 1), 
(21, 32, 1), 
(21, 33, 1), 
(21, 34, 1), 
(21, 35, 1), 
(21, 18, 1), 
(21, 19, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 22, 1), 
(21, 23, 1), 
(21, 24, 1), 
(21, 25, 1), 
(21, 26, 1), 
(21, 27, 1), 
(21, 56, 1), 
(22, 1, 2), 
(22, 36, 2), 
(22, 37, 2), 
(22, 38, 2), 
(22, 39, 2), 
(22, 45, 2), 
(22, 46, 2), 
(22, 47, 2), 
(22, 48, 2), 
(22, 55, 2), 
(22, 58, 2), 
(22, 4, 2), 
(22, 5, 2), 
(22, 6, 2), 
(22, 7, 2), 
(22, 8, 2), 
(22, 9, 2), 
(22, 10, 2), 
(22, 11, 2), 
(22, 12, 2), 
(22, 49, 2), 
(22, 57, 2), 
(22, 52, 2), 
(22, 53, 2), 
(22, 29, 2), 
(22, 30, 2), 
(22, 31, 2), 
(22, 32, 2), 
(22, 33, 2), 
(22, 34, 2), 
(22, 35, 2), 
(22, 18, 2), 
(22, 19, 2), 
(22, 20, 2), 
(22, 21, 2), 
(22, 22, 2), 
(22, 23, 2), 
(22, 24, 2), 
(22, 25, 2), 
(22, 26, 2), 
(22, 27, 2), 
(22, 56, 2), 
(23, 1, 3), 
(23, 36, 3), 
(23, 37, 3), 
(23, 38, 3), 
(23, 39, 3), 
(23, 45, 3), 
(23, 46, 3), 
(23, 47, 3), 
(23, 48, 3), 
(23, 55, 3), 
(23, 58, 3), 
(23, 4, 3), 
(23, 5, 3), 
(23, 6, 3), 
(23, 7, 3), 
(23, 8, 3), 
(23, 9, 3), 
(23, 10, 3), 
(23, 11, 3), 
(23, 12, 3), 
(23, 49, 3), 
(23, 57, 3), 
(23, 52, 3), 
(23, 53, 3), 
(23, 29, 3), 
(23, 30, 3), 
(23, 31, 3), 
(23, 32, 3), 
(23, 33, 3), 
(23, 34, 3), 
(23, 35, 3), 
(23, 18, 3), 
(23, 19, 3), 
(23, 20, 3), 
(23, 21, 3), 
(23, 22, 3), 
(23, 23, 3), 
(23, 24, 3), 
(23, 25, 3), 
(23, 26, 3), 
(23, 27, 3), 
(23, 56, 3), 
(24, 1, 4), 
(24, 36, 4), 
(24, 37, 4), 
(24, 38, 4), 
(24, 39, 4), 
(24, 45, 4), 
(24, 46, 4), 
(24, 47, 4), 
(24, 48, 4), 
(24, 55, 4), 
(24, 58, 4), 
(24, 4, 4), 
(24, 5, 4), 
(24, 6, 4), 
(24, 7, 4), 
(24, 8, 4), 
(24, 9, 4), 
(24, 10, 4), 
(24, 11, 4), 
(24, 12, 4), 
(24, 49, 4), 
(24, 57, 4), 
(24, 52, 4), 
(24, 53, 4), 
(24, 29, 4), 
(24, 30, 4), 
(24, 31, 4), 
(24, 32, 4), 
(24, 33, 4), 
(24, 34, 4), 
(24, 35, 4), 
(24, 18, 4), 
(24, 19, 4), 
(24, 20, 4), 
(24, 21, 4), 
(24, 22, 4), 
(24, 23, 4), 
(24, 24, 4), 
(24, 25, 4), 
(24, 26, 4), 
(24, 27, 4), 
(24, 56, 4), 
(28, 1, 1), 
(28, 36, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 45, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 55, 1), 
(28, 58, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 49, 1), 
(28, 57, 1), 
(28, 52, 1), 
(28, 53, 1), 
(28, 29, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 56, 1), 
(29, 1, 1), 
(29, 36, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 45, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 55, 1), 
(29, 58, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 49, 1), 
(29, 57, 1), 
(29, 52, 1), 
(29, 53, 1), 
(29, 29, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 56, 1), 
(33, 4, 1), 
(33, 5, 1), 
(33, 6, 1), 
(33, 7, 1), 
(33, 8, 1), 
(33, 9, 1), 
(33, 10, 1), 
(33, 11, 1), 
(33, 12, 1), 
(35, 1, 2), 
(35, 36, 1), 
(35, 37, 1), 
(35, 38, 1), 
(35, 39, 1), 
(35, 45, 1), 
(35, 46, 1), 
(35, 47, 1), 
(35, 48, 1), 
(35, 55, 1), 
(35, 58, 1), 
(35, 4, 2), 
(35, 5, 2), 
(35, 6, 2), 
(35, 7, 2), 
(35, 8, 3), 
(35, 9, 2), 
(35, 10, 2), 
(35, 11, 2), 
(35, 12, 2), 
(35, 49, 1), 
(35, 57, 1), 
(35, 52, 1), 
(35, 53, 1), 
(35, 29, 1), 
(35, 30, 1), 
(35, 31, 1), 
(35, 32, 1), 
(35, 33, 1), 
(35, 34, 1), 
(35, 35, 1), 
(35, 18, 1), 
(35, 19, 1), 
(35, 20, 1), 
(35, 21, 1), 
(35, 22, 1), 
(35, 23, 1), 
(35, 24, 1), 
(35, 25, 1), 
(35, 26, 1), 
(35, 27, 1), 
(35, 56, 1), 
(36, 1, 1), 
(36, 36, 1), 
(36, 37, 1), 
(36, 38, 1), 
(36, 39, 1), 
(36, 45, 1), 
(36, 46, 1), 
(36, 47, 1), 
(36, 48, 1), 
(36, 55, 1), 
(36, 58, 1), 
(36, 4, 1), 
(36, 5, 1), 
(36, 6, 1), 
(36, 7, 1), 
(36, 8, 1), 
(36, 9, 1), 
(36, 10, 1), 
(36, 11, 1), 
(36, 12, 1), 
(36, 49, 1), 
(36, 57, 1), 
(36, 52, 1), 
(36, 53, 1), 
(36, 29, 1), 
(36, 30, 1), 
(36, 31, 1), 
(36, 32, 1), 
(36, 33, 1), 
(36, 34, 1), 
(36, 35, 1), 
(36, 18, 1), 
(36, 19, 1), 
(36, 20, 1), 
(36, 21, 1), 
(36, 22, 1), 
(36, 23, 1), 
(36, 24, 1), 
(36, 25, 1), 
(36, 26, 1), 
(36, 27, 1), 
(36, 56, 1), 
(38, 1, 1), 
(38, 36, 1), 
(38, 37, 1), 
(38, 38, 1), 
(38, 39, 1), 
(38, 45, 1), 
(38, 46, 1), 
(38, 47, 1), 
(38, 48, 1), 
(38, 55, 1), 
(38, 58, 1), 
(38, 4, 1), 
(38, 5, 1), 
(38, 6, 1), 
(38, 7, 1), 
(38, 8, 1), 
(38, 9, 1), 
(38, 10, 1), 
(38, 11, 1), 
(38, 12, 1), 
(38, 49, 1), 
(38, 57, 1), 
(38, 52, 1), 
(38, 53, 1), 
(38, 29, 1), 
(38, 30, 1), 
(38, 31, 1), 
(38, 32, 1), 
(38, 33, 1), 
(38, 34, 1), 
(38, 35, 1), 
(38, 18, 1), 
(38, 19, 1), 
(38, 20, 1), 
(38, 21, 1), 
(38, 22, 1), 
(38, 23, 1), 
(38, 24, 1), 
(38, 25, 1), 
(38, 26, 1), 
(38, 27, 1), 
(38, 56, 1), 
(40, 1, 4), 
(40, 36, 4), 
(40, 37, 4), 
(40, 38, 4), 
(40, 39, 4), 
(40, 45, 4), 
(40, 46, 4), 
(40, 47, 4), 
(40, 48, 4), 
(40, 55, 4), 
(40, 58, 4), 
(40, 4, 4), 
(40, 5, 4), 
(40, 6, 4), 
(40, 7, 4), 
(40, 8, 4), 
(40, 9, 4), 
(40, 10, 4), 
(40, 11, 4), 
(40, 12, 4), 
(40, 49, 4), 
(40, 57, 4), 
(40, 52, 4), 
(40, 53, 4), 
(40, 29, 4), 
(40, 30, 4), 
(40, 31, 4), 
(40, 32, 4), 
(40, 33, 4), 
(40, 34, 4), 
(40, 35, 4), 
(40, 18, 4), 
(40, 19, 4), 
(40, 20, 4), 
(40, 21, 4), 
(40, 22, 4), 
(40, 23, 4), 
(40, 24, 4), 
(40, 25, 4), 
(40, 26, 4), 
(40, 27, 4), 
(40, 56, 4), 
(43, 1, 1), 
(43, 36, 1), 
(43, 37, 1), 
(43, 38, 1), 
(43, 39, 1), 
(43, 45, 1), 
(43, 46, 1), 
(43, 47, 1), 
(43, 48, 1), 
(43, 55, 1), 
(43, 58, 1), 
(43, 4, 1), 
(43, 5, 1), 
(43, 6, 1), 
(43, 7, 1), 
(43, 8, 1), 
(43, 9, 1), 
(43, 10, 1), 
(43, 11, 1), 
(43, 12, 1), 
(43, 49, 1), 
(43, 57, 1), 
(43, 52, 1), 
(43, 53, 1), 
(43, 29, 1), 
(43, 30, 1), 
(43, 31, 1), 
(43, 32, 1), 
(43, 33, 1), 
(43, 34, 1), 
(43, 35, 1), 
(43, 18, 1), 
(43, 19, 1), 
(43, 20, 1), 
(43, 21, 1), 
(43, 22, 1), 
(43, 23, 1), 
(43, 24, 1), 
(43, 25, 1), 
(43, 26, 1), 
(43, 27, 1), 
(43, 56, 1), 
(44, 4, 1), 
(33, 1, 1), 
(33, 18, 2), 
(33, 19, 2), 
(33, 20, 2), 
(33, 21, 2), 
(33, 22, 2), 
(33, 23, 2), 
(33, 24, 2), 
(33, 25, 2), 
(33, 26, 2), 
(33, 27, 2), 
(33, 55, 2), 
(33, 29, 2), 
(33, 30, 2), 
(33, 31, 2), 
(33, 32, 2), 
(33, 33, 2), 
(33, 34, 2), 
(33, 35, 2), 
(33, 56, 2), 
(33, 36, 2), 
(33, 37, 2), 
(33, 38, 2), 
(33, 39, 2), 
(33, 57, 2), 
(33, 58, 2), 
(33, 49, 2), 
(33, 45, 2), 
(33, 46, 2), 
(33, 47, 2), 
(33, 48, 2), 
(33, 52, 2), 
(33, 53, 2), 
(13, 59, 1), 
(13, 60, 1), 
(15, 59, 1), 
(15, 60, 1), 
(18, 59, 1), 
(18, 60, 1), 
(8, 59, 1), 
(8, 60, 1), 
(9, 59, 2), 
(9, 60, 2), 
(5, 59, 1), 
(5, 60, 1), 
(17, 59, 1), 
(17, 60, 1), 
(14, 59, 1), 
(14, 60, 1), 
(12, 59, 1), 
(12, 60, 1), 
(10, 59, 1), 
(10, 60, 1), 
(11, 59, 2), 
(11, 60, 2), 
(6, 59, 1), 
(6, 60, 1), 
(7, 59, 2), 
(7, 60, 2), 
(16, 59, 1), 
(16, 60, 1), 
(28, 59, 1), 
(28, 60, 1), 
(29, 59, 1), 
(29, 60, 1), 
(35, 59, 1), 
(35, 60, 1), 
(36, 59, 1), 
(36, 60, 1), 
(38, 59, 1), 
(38, 60, 1), 
(40, 59, 4), 
(40, 60, 4), 
(43, 59, 1), 
(43, 60, 1), 
(27, 59, 1), 
(27, 60, 1), 
(25, 59, 1), 
(25, 60, 1), 
(26, 59, 1), 
(26, 60, 1), 
(19, 59, 1), 
(19, 60, 1), 
(20, 59, 2), 
(20, 60, 2), 
(21, 59, 1), 
(21, 60, 1), 
(22, 59, 2), 
(22, 60, 2), 
(23, 59, 3), 
(23, 60, 3), 
(24, 59, 4), 
(24, 60, 4), 
(46, 1, 1), 
(46, 4, 2), 
(46, 5, 1), 
(46, 6, 1), 
(46, 7, 1), 
(46, 8, 1), 
(46, 9, 1), 
(46, 10, 1), 
(46, 11, 1), 
(46, 12, 1), 
(46, 18, 1), 
(46, 19, 1), 
(46, 20, 1), 
(46, 21, 1), 
(46, 22, 1), 
(46, 23, 1), 
(46, 24, 1), 
(46, 25, 1), 
(46, 26, 1), 
(46, 27, 1), 
(46, 55, 1), 
(46, 29, 1), 
(46, 30, 1), 
(46, 31, 1), 
(46, 32, 1), 
(46, 33, 1), 
(46, 34, 1), 
(46, 35, 1), 
(46, 56, 1), 
(46, 36, 1), 
(46, 37, 1), 
(46, 38, 1), 
(46, 39, 1), 
(46, 57, 1), 
(46, 58, 1), 
(46, 49, 1), 
(46, 45, 1), 
(46, 46, 1), 
(46, 47, 1), 
(46, 48, 1), 
(46, 52, 1), 
(46, 53, 1), 
(46, 59, 1), 
(46, 60, 1), 
(33, 59, 2), 
(33, 60, 2), 
(13, 62, 1), 
(13, 63, 1), 
(15, 62, 1), 
(15, 63, 1), 
(18, 62, 1), 
(18, 63, 1), 
(8, 62, 1), 
(8, 63, 1), 
(9, 62, 2), 
(9, 63, 2), 
(5, 62, 1), 
(5, 63, 1), 
(17, 62, 1), 
(17, 63, 1), 
(14, 62, 1), 
(14, 63, 1), 
(12, 62, 1), 
(12, 63, 1), 
(10, 62, 1), 
(10, 63, 1), 
(11, 62, 2), 
(11, 63, 2), 
(6, 62, 1), 
(6, 63, 1), 
(7, 62, 2), 
(7, 63, 2), 
(16, 62, 1), 
(16, 63, 1), 
(28, 62, 1), 
(28, 63, 1), 
(29, 62, 1), 
(29, 63, 1), 
(33, 62, 1), 
(33, 63, 1), 
(35, 62, 2), 
(35, 63, 2), 
(36, 62, 1), 
(36, 63, 1), 
(38, 62, 1), 
(38, 63, 1), 
(40, 62, 4), 
(40, 63, 4), 
(46, 62, 1), 
(46, 63, 1), 
(43, 62, 1), 
(43, 63, 1), 
(27, 62, 1), 
(27, 63, 1), 
(25, 62, 1), 
(25, 63, 1), 
(26, 62, 1), 
(26, 63, 1), 
(19, 62, 1), 
(19, 63, 1), 
(20, 62, 2), 
(20, 63, 2), 
(21, 62, 1), 
(21, 63, 1), 
(22, 62, 2), 
(22, 63, 2), 
(23, 62, 3), 
(23, 63, 3), 
(24, 62, 4), 
(24, 63, 4), 
(47, 1, 2), 
(47, 4, 1), 
(47, 5, 2), 
(47, 6, 2), 
(47, 7, 2), 
(47, 8, 2), 
(47, 9, 2), 
(47, 10, 2), 
(47, 11, 2), 
(47, 12, 2), 
(47, 18, 2), 
(47, 19, 2), 
(47, 20, 2), 
(47, 21, 2), 
(47, 22, 2), 
(47, 23, 2), 
(47, 24, 2), 
(47, 25, 2), 
(47, 26, 2), 
(47, 27, 2), 
(47, 55, 2), 
(47, 29, 2), 
(47, 30, 2), 
(47, 31, 2), 
(47, 32, 2), 
(47, 33, 2), 
(47, 34, 2), 
(47, 35, 2), 
(47, 56, 2), 
(47, 36, 2), 
(47, 37, 2), 
(47, 38, 2), 
(47, 39, 2), 
(47, 57, 2), 
(47, 58, 2), 
(47, 49, 2), 
(47, 45, 2), 
(47, 46, 2), 
(47, 47, 2), 
(47, 48, 2), 
(47, 52, 2), 
(47, 53, 2), 
(47, 59, 2), 
(47, 60, 2), 
(47, 62, 2), 
(47, 63, 2), 
(48, 63, 3), 
(48, 4, 3), 
(48, 5, 3), 
(48, 6, 3), 
(48, 7, 3), 
(48, 8, 3), 
(48, 9, 3), 
(48, 10, 3), 
(48, 11, 3), 
(48, 12, 3), 
(48, 62, 3), 
(48, 60, 3), 
(48, 59, 3), 
(48, 53, 3), 
(48, 52, 3), 
(48, 48, 3), 
(48, 47, 3), 
(48, 46, 3), 
(48, 45, 3), 
(48, 49, 3), 
(48, 24, 3), 
(48, 58, 3), 
(48, 57, 3), 
(48, 39, 3), 
(48, 38, 3), 
(48, 37, 3), 
(48, 36, 3), 
(48, 56, 3), 
(48, 23, 3), 
(48, 35, 3), 
(48, 34, 3), 
(48, 33, 3), 
(48, 32, 3), 
(48, 22, 3), 
(48, 21, 3), 
(48, 27, 3), 
(48, 31, 3), 
(48, 30, 3), 
(48, 29, 3), 
(48, 55, 3), 
(48, 26, 3), 
(48, 25, 3), 
(48, 20, 3), 
(48, 19, 3), 
(48, 18, 3), 
(48, 1, 3), 
(49, 4, 1), 
(49, 5, 1), 
(49, 6, 1), 
(49, 7, 1), 
(49, 8, 1), 
(49, 9, 1), 
(49, 10, 1), 
(49, 11, 1), 
(49, 12, 1), 
(50, 1, 3), 
(50, 4, 3), 
(50, 5, 3), 
(50, 6, 3), 
(50, 7, 3), 
(50, 8, 2), 
(50, 9, 3), 
(50, 10, 3), 
(50, 11, 3), 
(50, 12, 3), 
(50, 18, 3), 
(50, 19, 3), 
(50, 20, 3), 
(50, 21, 3), 
(50, 22, 3), 
(50, 23, 3), 
(50, 24, 3), 
(50, 25, 3), 
(50, 26, 3), 
(50, 27, 3), 
(50, 55, 3), 
(50, 29, 3), 
(50, 30, 3), 
(50, 31, 3), 
(50, 32, 3), 
(50, 33, 3), 
(50, 34, 3), 
(50, 35, 3), 
(50, 56, 3), 
(50, 36, 3), 
(50, 37, 3), 
(50, 38, 3), 
(50, 39, 3), 
(50, 57, 3), 
(50, 58, 3), 
(50, 49, 3), 
(50, 45, 3), 
(50, 46, 3), 
(50, 47, 3), 
(50, 48, 3), 
(50, 52, 3), 
(50, 53, 3), 
(50, 59, 3), 
(50, 60, 3), 
(50, 62, 3), 
(50, 63, 3), 
(52, 1, 4), 
(52, 4, 4), 
(52, 5, 4), 
(52, 6, 4), 
(52, 7, 4), 
(52, 8, 4), 
(52, 9, 4), 
(52, 10, 4), 
(52, 11, 4), 
(52, 12, 4), 
(52, 18, 4), 
(52, 19, 4), 
(52, 20, 4), 
(52, 21, 4), 
(52, 22, 4), 
(52, 23, 4), 
(52, 24, 4), 
(52, 25, 4), 
(52, 26, 4), 
(52, 27, 4), 
(52, 55, 4), 
(52, 29, 4), 
(52, 30, 4), 
(52, 31, 4), 
(52, 32, 4), 
(52, 33, 4), 
(52, 34, 4), 
(52, 35, 4), 
(52, 56, 4), 
(52, 36, 4), 
(52, 37, 4), 
(52, 38, 4), 
(52, 39, 4), 
(52, 57, 4), 
(52, 58, 4), 
(52, 49, 4), 
(52, 45, 4), 
(52, 46, 4), 
(52, 47, 4), 
(52, 48, 4), 
(52, 52, 4), 
(52, 53, 4), 
(52, 59, 4), 
(52, 60, 4), 
(52, 62, 4), 
(52, 63, 4), 
(13, 68, 1), 
(13, 78, 1), 
(13, 77, 1), 
(13, 67, 1), 
(13, 66, 1), 
(13, 73, 1), 
(13, 65, 1), 
(13, 76, 1), 
(13, 71, 1), 
(15, 68, 1), 
(15, 78, 1), 
(15, 77, 1), 
(15, 67, 1), 
(15, 66, 1), 
(15, 73, 1), 
(15, 65, 1), 
(15, 76, 1), 
(15, 71, 1), 
(18, 68, 1), 
(18, 78, 1), 
(18, 77, 1), 
(18, 67, 1), 
(18, 66, 1), 
(18, 73, 1), 
(18, 65, 1), 
(18, 76, 1), 
(18, 71, 1), 
(8, 68, 1), 
(8, 78, 1), 
(8, 77, 1), 
(8, 67, 1), 
(8, 66, 1), 
(8, 73, 1), 
(8, 65, 1), 
(8, 76, 1), 
(8, 71, 1), 
(9, 68, 2), 
(9, 78, 2), 
(9, 77, 2), 
(9, 67, 2), 
(9, 66, 2), 
(9, 73, 2), 
(9, 65, 2), 
(9, 76, 2), 
(9, 71, 2), 
(5, 68, 1), 
(5, 78, 1), 
(5, 77, 1), 
(5, 67, 1), 
(5, 66, 1), 
(5, 73, 1), 
(5, 65, 1), 
(5, 76, 1), 
(5, 71, 1), 
(17, 68, 1), 
(17, 78, 1), 
(17, 77, 1), 
(17, 67, 1), 
(17, 66, 1), 
(17, 73, 1), 
(17, 65, 1), 
(17, 76, 1), 
(17, 71, 1), 
(14, 68, 1), 
(14, 78, 1), 
(14, 77, 1), 
(14, 67, 1), 
(14, 66, 1), 
(14, 73, 1), 
(14, 65, 1), 
(14, 76, 1), 
(14, 71, 1), 
(12, 68, 1), 
(12, 78, 1), 
(12, 77, 1), 
(12, 67, 1), 
(12, 66, 1), 
(12, 73, 1), 
(12, 65, 1), 
(12, 76, 1), 
(12, 71, 1), 
(10, 68, 1), 
(10, 78, 1), 
(10, 77, 1), 
(10, 67, 1), 
(10, 66, 1), 
(10, 73, 1), 
(10, 65, 1), 
(10, 76, 1), 
(10, 71, 1), 
(11, 68, 2), 
(11, 78, 2), 
(11, 77, 2), 
(11, 67, 2), 
(11, 66, 2), 
(11, 73, 2), 
(11, 65, 2), 
(11, 76, 2), 
(11, 71, 2), 
(6, 68, 1), 
(6, 78, 1), 
(6, 77, 1), 
(6, 67, 1), 
(6, 66, 1), 
(6, 73, 1), 
(6, 65, 1), 
(6, 76, 1), 
(6, 71, 1), 
(7, 68, 2), 
(7, 78, 2), 
(7, 77, 2), 
(7, 67, 2), 
(7, 66, 2), 
(7, 73, 2), 
(7, 65, 2), 
(7, 76, 2), 
(7, 71, 2), 
(16, 68, 1), 
(16, 78, 1), 
(16, 77, 1), 
(16, 67, 1), 
(16, 66, 1), 
(16, 73, 1), 
(16, 65, 1), 
(16, 76, 1), 
(16, 71, 1), 
(29, 68, 1), 
(29, 78, 1), 
(29, 77, 1), 
(29, 67, 1), 
(29, 66, 1), 
(29, 73, 1), 
(29, 65, 1), 
(29, 76, 1), 
(29, 71, 1), 
(28, 68, 1), 
(28, 78, 1), 
(28, 77, 1), 
(28, 67, 1), 
(28, 66, 1), 
(28, 73, 1), 
(28, 65, 1), 
(28, 76, 1), 
(28, 71, 1), 
(33, 68, 1), 
(33, 78, 1), 
(33, 77, 1), 
(33, 67, 1), 
(33, 66, 1), 
(33, 73, 1), 
(33, 65, 1), 
(33, 76, 1), 
(33, 71, 1), 
(35, 68, 2), 
(35, 78, 2), 
(35, 77, 2), 
(35, 67, 2), 
(35, 66, 2), 
(35, 73, 2), 
(35, 65, 2), 
(35, 76, 2), 
(35, 71, 2), 
(50, 68, 3), 
(50, 78, 3), 
(50, 77, 3), 
(50, 67, 3), 
(50, 66, 3), 
(50, 73, 3), 
(50, 65, 3), 
(50, 76, 3), 
(50, 71, 3), 
(40, 68, 4), 
(40, 78, 4), 
(40, 77, 4), 
(40, 67, 4), 
(40, 66, 4), 
(40, 73, 4), 
(40, 65, 4), 
(40, 76, 4), 
(40, 71, 4), 
(36, 68, 1), 
(36, 78, 1), 
(36, 77, 1), 
(36, 67, 1), 
(36, 66, 1), 
(36, 73, 1), 
(36, 65, 1), 
(36, 76, 1), 
(36, 71, 1), 
(38, 68, 1), 
(38, 78, 1), 
(38, 77, 1), 
(38, 67, 1), 
(38, 66, 1), 
(38, 73, 1), 
(38, 65, 1), 
(38, 76, 1), 
(38, 71, 1), 
(47, 68, 1), 
(47, 78, 1), 
(47, 77, 1), 
(47, 67, 1), 
(47, 66, 1), 
(47, 73, 1), 
(47, 65, 1), 
(47, 76, 1), 
(47, 71, 1), 
(46, 68, 2), 
(46, 78, 2), 
(46, 77, 2), 
(46, 67, 2), 
(46, 66, 2), 
(46, 73, 2), 
(46, 65, 2), 
(46, 76, 2), 
(46, 71, 2), 
(48, 68, 3), 
(48, 78, 3), 
(48, 77, 3), 
(48, 67, 3), 
(48, 66, 3), 
(48, 73, 3), 
(48, 65, 3), 
(48, 76, 3), 
(48, 71, 3), 
(52, 68, 4), 
(52, 78, 4), 
(52, 77, 4), 
(52, 67, 4), 
(52, 66, 4), 
(52, 73, 4), 
(52, 65, 4), 
(52, 76, 4), 
(52, 71, 4), 
(43, 68, 1), 
(43, 78, 1), 
(43, 77, 1), 
(43, 67, 1), 
(43, 66, 1), 
(43, 73, 1), 
(43, 65, 1), 
(43, 76, 1), 
(43, 71, 1), 
(27, 68, 1), 
(27, 78, 1), 
(27, 77, 1), 
(27, 67, 1), 
(27, 66, 1), 
(27, 73, 1), 
(27, 65, 1), 
(27, 76, 1), 
(27, 71, 1), 
(25, 68, 1), 
(25, 78, 1), 
(25, 77, 1), 
(25, 67, 1), 
(25, 66, 1), 
(25, 73, 1), 
(25, 65, 1), 
(25, 76, 1), 
(25, 71, 1), 
(26, 68, 1), 
(26, 78, 1), 
(26, 77, 1), 
(26, 67, 1), 
(26, 66, 1), 
(26, 73, 1), 
(26, 65, 1), 
(26, 76, 1), 
(26, 71, 1), 
(19, 68, 1), 
(19, 78, 1), 
(19, 77, 1), 
(19, 67, 1), 
(19, 66, 1), 
(19, 73, 1), 
(19, 65, 1), 
(19, 76, 1), 
(19, 71, 1), 
(20, 68, 2), 
(20, 78, 2), 
(20, 77, 2), 
(20, 67, 2), 
(20, 66, 2), 
(20, 73, 2), 
(20, 65, 2), 
(20, 76, 2), 
(20, 71, 2), 
(21, 68, 1), 
(21, 78, 1), 
(21, 77, 1), 
(21, 67, 1), 
(21, 66, 1), 
(21, 73, 1), 
(21, 65, 1), 
(21, 76, 1), 
(21, 71, 1), 
(22, 68, 2), 
(22, 78, 2), 
(22, 77, 2), 
(22, 67, 2), 
(22, 66, 2), 
(22, 73, 2), 
(22, 65, 2), 
(22, 76, 2), 
(22, 71, 2), 
(23, 68, 3), 
(23, 78, 3), 
(23, 77, 3), 
(23, 67, 3), 
(23, 66, 3), 
(23, 73, 3), 
(23, 65, 3), 
(23, 76, 3), 
(23, 71, 3), 
(24, 68, 4), 
(24, 78, 4), 
(24, 77, 4), 
(24, 67, 4), 
(24, 66, 4), 
(24, 73, 4), 
(24, 65, 4), 
(24, 76, 4), 
(24, 71, 4);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_comment`
--

DROP TABLE IF EXISTS `gt_vi_comment`;
CREATE TABLE `gt_vi_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_contact_department`
--

DROP TABLE IF EXISTS `gt_vi_contact_department`;
CREATE TABLE `gt_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `others` text NOT NULL,
  `cats` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_contact_department`
--

INSERT INTO `gt_vi_contact_department` VALUES
(1, 'Phòng Chăm sóc khách hàng', 'Cham-soc-khach-hang', '(08) 38.000.000[+84838000000]', '08 38.000.001', 'customer@mysite.com', 'Bộ phận tiếp nhận và giải quyết các yêu cầu, đề nghị, ý kiến liên quan đến hoạt động chính của doanh nghiệp', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Tư vấn|Khiếu nại, phản ánh|Đề nghị hợp tác', '1/1/1/0;', 1, 1, 1), 
(2, 'Phòng Kỹ thuật', 'Ky-thuat', '(08) 38.000.002[+84838000002]', '08 38.000.003', 'technical@mysite.com', 'Bộ phận tiếp nhận và giải quyết các câu hỏi liên quan đến kỹ thuật', '{\"viber\":\"myViber2\",\"skype\":\"mySkype2\",\"yahoo\":\"myYahoo2\"}', 'Thông báo lỗi|Góp ý cải tiến', '1/1/1/0;', 1, 2, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_contact_reply`
--

DROP TABLE IF EXISTS `gt_vi_contact_reply`;
CREATE TABLE `gt_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_contact_send`
--

DROP TABLE IF EXISTS `gt_vi_contact_send`;
CREATE TABLE `gt_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(20) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_freecontent_blocks`
--

DROP TABLE IF EXISTS `gt_vi_freecontent_blocks`;
CREATE TABLE `gt_vi_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_freecontent_blocks`
--

INSERT INTO `gt_vi_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_freecontent_rows`
--

DROP TABLE IF EXISTS `gt_vi_freecontent_rows`;
CREATE TABLE `gt_vi_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255) NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_freecontent_rows`
--

INSERT INTO `gt_vi_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'nukeviet.jpg', 1448557801, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'nukeviet-portal.jpg', 1448557801, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'nukeviet-edu.jpg', 1448557801, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'nukeviet-toasoan.jpg', 1448557801, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_menu`
--

DROP TABLE IF EXISTS `gt_vi_menu`;
CREATE TABLE `gt_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_menu`
--

INSERT INTO `gt_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_menu_rows`
--

DROP TABLE IF EXISTS `gt_vi_menu_rows`;
CREATE TABLE `gt_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=120  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_menu_rows`
--

INSERT INTO `gt_vi_menu_rows` VALUES
(119, 0, 1, 'Liên hệ', '/news/index.php?language=vi&nv=contact', '', '', 12, 16, 0, '', '6', 'contact', '', 1, '', 0, 1), 
(117, 0, 1, 'Rss', '/news/index.php?language=vi&nv=news&amp;op=rss', '', '', 10, 14, 0, '', '6', 'news', 'rss', 1, '', 1, 0), 
(118, 0, 1, 'Search', '/news/index.php?language=vi&nv=news&amp;op=search', '', '', 11, 15, 0, '', '6', 'news', 'search', 1, '', 1, 0), 
(116, 0, 1, 'Content', '/news/index.php?language=vi&nv=news&amp;op=content', '', '', 9, 13, 0, '', '6', 'news', 'content', 1, '', 1, 0), 
(115, 0, 1, 'Chung tay', '/news/index.php?language=vi&nv=news&amp;op=chung-tay', '', '', 8, 12, 0, '', '6', 'news', 'chung-tay', 1, '', 1, 1), 
(114, 0, 1, 'Thời khóa biểu', '/news/index.php?language=vi&nv=news&amp;op=thoi-khoa-bieu', '', '', 7, 11, 0, '', '6', 'news', 'thoi-khoa-bieu', 1, '', 1, 1), 
(113, 0, 1, 'Thư viện', '/news/index.php?language=vi&nv=news&amp;op=thu-vien', '', '', 6, 10, 0, '', '6', 'news', 'thu-vien', 1, '', 1, 1), 
(112, 0, 1, 'Tin học', '/news/index.php?language=vi&nv=news&amp;op=tin-hoc', '', '', 5, 9, 0, '', '6', 'news', 'tin-hoc', 1, '', 1, 1), 
(111, 0, 1, 'Phương pháp học tập', '/news/index.php?language=vi&nv=news&amp;op=phuong-phap-hop-tap', '', '', 4, 8, 0, '', '6', 'news', 'phuong-phap-hop-tap', 1, '', 1, 1), 
(110, 0, 1, 'Sự kiện', '/news/index.php?language=vi&nv=news&amp;op=su-kien', '', '', 3, 7, 0, '', '6', 'news', 'su-kien', 1, '', 1, 1), 
(109, 108, 1, 'Chào cờ', '/news/index.php?language=vi&nv=news&amp;op=chao-co', '', '', 1, 6, 1, '', '6', 'news', 'chao-co', 1, '', 1, 1), 
(108, 0, 1, 'Hoạt động', '/news/index.php?language=vi&nv=news&amp;op=hoat-dong', '', '', 2, 5, 0, '109', '6', 'news', 'hoat-dong', 1, '', 1, 1), 
(107, 104, 1, 'Tổ chuyên môn', '/news/index.php?language=vi&nv=news&amp;op=to-chuyen-mon', '', '', 3, 4, 1, '', '6', 'news', 'to-chuyen-mon', 1, '', 1, 1), 
(104, 0, 1, 'Nhà trường', '/news/index.php?language=vi&nv=news&amp;op=nha-truong', '', '', 1, 1, 0, '105,106,107', '6', 'news', 'nha-truong', 1, '', 1, 1), 
(105, 104, 1, 'Giới thiệu', '/news/index.php?language=vi&nv=news&amp;op=gioi-thieu', '', '', 1, 2, 1, '', '6', 'news', 'gioi-thieu', 1, '', 1, 1), 
(106, 104, 1, 'Ban giám hiệu', '/news/index.php?language=vi&nv=news&amp;op=ban-giam-hieu', '', '', 2, 3, 1, '', '6', 'news', 'ban-giam-hieu', 1, '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_modfuncs`
--

DROP TABLE IF EXISTS `gt_vi_modfuncs`;
CREATE TABLE `gt_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=79  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_modfuncs`
--

INSERT INTO `gt_vi_modfuncs` VALUES
(1, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', 'about', 0, 0, 0, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Đăng ký', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Quên mật khẩu', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Kích hoạt', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Thiếp lập tài khoản', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Thoát', 'users', 1, 1, 10, ''), 
(28, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(29, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(30, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(31, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(32, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(33, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(34, 'allbots', 'allbots', 'Máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(35, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(36, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(37, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(38, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(39, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(40, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(41, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(42, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(43, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(46, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(47, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(48, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(49, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(50, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(51, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''), 
(52, 'main', 'main', 'Main', 'siteterms', 1, 0, 1, ''), 
(53, 'rss', 'rss', 'Rss', 'siteterms', 1, 0, 2, ''), 
(54, 'sitemap', 'sitemap', 'Sitemap', 'siteterms', 0, 0, 0, ''), 
(55, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(56, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(59, 'main', 'main', 'Main', 'video-clip', 1, 0, 1, ''), 
(60, 'rss', 'rss', 'Rss', 'video-clip', 1, 0, 2, ''), 
(61, 'sitemap', 'sitemap', 'Sitemap', 'video-clip', 0, 0, 0, ''), 
(62, 'main', 'main', 'Main', 'tra-cuu-diem-thi', 1, 0, 1, ''), 
(63, 'rss', 'rss', 'Rss', 'tra-cuu-diem-thi', 1, 0, 2, ''), 
(64, 'sitemap', 'sitemap', 'Sitemap', 'tra-cuu-diem-thi', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_modthemes`
--

DROP TABLE IF EXISTS `gt_vi_modthemes`;
CREATE TABLE `gt_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_modthemes`
--

INSERT INTO `gt_vi_modthemes` VALUES
(0, 'body', 'mobile_default'), 
(0, 'left-body-right', 'default'), 
(0, 'left-body-right', 'giaothanh'), 
(1, 'body', 'mobile_default'), 
(1, 'left-body-right', 'default'), 
(1, 'left-body-right', 'giaothanh'), 
(4, 'body', 'mobile_default'), 
(4, 'left-body-right', 'default'), 
(4, 'left-body-right', 'giaothanh'), 
(5, 'body', 'mobile_default'), 
(5, 'left-body-right', 'default'), 
(5, 'left-body-right', 'giaothanh'), 
(6, 'body', 'mobile_default'), 
(6, 'left-body-right', 'default'), 
(6, 'left-body-right', 'giaothanh'), 
(7, 'body', 'mobile_default'), 
(7, 'left-body-right', 'default'), 
(7, 'left-body-right', 'giaothanh'), 
(8, 'body', 'mobile_default'), 
(8, 'left-body-right', 'default'), 
(8, 'left-body-right', 'giaothanh'), 
(9, 'body', 'mobile_default'), 
(9, 'left-body-right', 'default'), 
(9, 'left-body-right', 'giaothanh'), 
(10, 'left-body-right', 'default'), 
(10, 'left-body-right', 'giaothanh'), 
(11, 'body', 'mobile_default'), 
(11, 'left-body-right', 'default'), 
(11, 'left-body-right', 'giaothanh'), 
(12, 'body', 'mobile_default'), 
(12, 'left-body-right', 'default'), 
(12, 'left-body-right', 'giaothanh'), 
(18, 'body', 'mobile_default'), 
(18, 'left-body', 'default'), 
(18, 'left-body-right', 'giaothanh'), 
(19, 'body', 'mobile_default'), 
(19, 'left-body', 'default'), 
(19, 'left-body-right', 'giaothanh'), 
(20, 'body', 'mobile_default'), 
(20, 'left-body', 'default'), 
(20, 'left-body-right', 'giaothanh'), 
(21, 'body', 'mobile_default'), 
(21, 'left-body', 'default'), 
(21, 'left-body-right', 'giaothanh'), 
(22, 'body', 'mobile_default'), 
(22, 'left-body', 'default'), 
(22, 'left-body-right', 'giaothanh'), 
(23, 'body', 'mobile_default'), 
(23, 'left-body', 'default'), 
(23, 'left-body-right', 'giaothanh'), 
(24, 'body', 'mobile_default'), 
(24, 'left-body', 'default'), 
(24, 'left-body-right', 'giaothanh'), 
(25, 'body', 'mobile_default'), 
(25, 'left-body', 'default'), 
(25, 'left-body-right', 'giaothanh'), 
(26, 'left-body', 'default'), 
(26, 'left-body-right', 'giaothanh'), 
(27, 'body', 'mobile_default'), 
(27, 'left-body', 'default'), 
(27, 'left-body-right', 'giaothanh'), 
(29, 'body', 'mobile_default'), 
(29, 'left-body', 'default'), 
(29, 'left-body-right', 'giaothanh'), 
(30, 'body', 'mobile_default'), 
(30, 'left-body', 'default'), 
(30, 'left-body-right', 'giaothanh'), 
(31, 'body', 'mobile_default'), 
(31, 'left-body', 'default'), 
(31, 'left-body-right', 'giaothanh'), 
(32, 'body', 'mobile_default'), 
(32, 'left-body', 'default'), 
(32, 'left-body-right', 'giaothanh'), 
(33, 'body', 'mobile_default'), 
(33, 'left-body', 'default'), 
(33, 'left-body-right', 'giaothanh'), 
(34, 'body', 'mobile_default'), 
(34, 'left-body', 'default'), 
(34, 'left-body-right', 'giaothanh'), 
(35, 'body', 'mobile_default'), 
(35, 'left-body', 'default'), 
(35, 'left-body-right', 'giaothanh'), 
(36, 'body', 'mobile_default'), 
(36, 'left-body-right', 'default'), 
(36, 'left-body-right', 'giaothanh'), 
(37, 'body', 'mobile_default'), 
(37, 'left-body-right', 'default'), 
(37, 'left-body-right', 'giaothanh'), 
(38, 'body', 'mobile_default'), 
(38, 'left-body-right', 'default'), 
(38, 'left-body-right', 'giaothanh'), 
(39, 'body', 'mobile_default'), 
(39, 'left-body-right', 'default'), 
(39, 'left-body-right', 'giaothanh'), 
(45, 'body', 'mobile_default'), 
(45, 'left-body-right', 'default'), 
(45, 'left-body-right', 'giaothanh'), 
(46, 'body', 'mobile_default'), 
(46, 'left-body-right', 'default'), 
(46, 'left-body-right', 'giaothanh'), 
(47, 'body', 'mobile_default'), 
(47, 'left-body-right', 'default'), 
(47, 'left-body-right', 'giaothanh'), 
(48, 'body', 'mobile_default'), 
(48, 'left-body-right', 'default'), 
(48, 'left-body-right', 'giaothanh'), 
(49, 'body', 'mobile_default'), 
(49, 'left-body', 'default'), 
(49, 'left-body-right', 'giaothanh'), 
(52, 'body', 'mobile_default'), 
(52, 'left-body-right', 'default'), 
(52, 'left-body-right', 'giaothanh'), 
(53, 'body', 'mobile_default'), 
(53, 'left-body-right', 'default'), 
(53, 'left-body-right', 'giaothanh'), 
(55, 'body', 'mobile_default'), 
(55, 'left-body', 'default'), 
(55, 'left-body-right', 'giaothanh'), 
(56, 'body', 'mobile_default'), 
(56, 'left-body', 'default'), 
(56, 'left-body-right', 'giaothanh'), 
(57, 'body', 'mobile_default'), 
(57, 'left-body-right', 'default'), 
(57, 'left-body-right', 'giaothanh'), 
(58, 'body', 'mobile_default'), 
(58, 'left-body-right', 'default'), 
(58, 'left-body-right', 'giaothanh'), 
(59, 'body', 'mobile_default'), 
(59, 'left-body-right', 'default'), 
(59, 'left-body-right', 'giaothanh'), 
(60, 'body', 'mobile_default'), 
(60, 'left-body-right', 'default'), 
(60, 'left-body-right', 'giaothanh'), 
(61, 'left-body-right', 'giaothanh'), 
(62, 'body', 'mobile_default'), 
(62, 'left-body-right', 'default'), 
(62, 'left-body-right', 'giaothanh'), 
(63, 'body', 'mobile_default'), 
(63, 'left-body-right', 'default'), 
(63, 'left-body-right', 'giaothanh'), 
(64, 'left-body-right', 'giaothanh');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_modules`
--

DROP TABLE IF EXISTS `gt_vi_modules`;
CREATE TABLE `gt_vi_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `module_upload` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_modules`
--

INSERT INTO `gt_vi_modules` VALUES
('about', 'page', 'about', 'about', 'Giới thiệu', '', 1448557801, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0), 
('news', 'news', 'news', 'news', 'Tin Tức', '', 1448557801, 1, 1, '', '', '', '', '6', 2, 1, '2', 1, 0), 
('users', 'users', 'users', 'users', 'Thành viên', 'Tài khoản', 1448557801, 1, 1, '', '', '', '', '6', 3, 1, '2', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Liên hệ', '', 1448557801, 1, 1, '', '', '', '', '6', 4, 1, '2', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', 1448557801, 1, 1, '', '', '', 'truy cập, online, statistics', '2', 5, 1, '2', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1448557801, 1, 1, '', '', '', '', '6', 6, 1, '2', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', 1448557801, 1, 1, '', '', '', '', '6', 7, 1, '2', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', 1448557801, 1, 0, '', '', '', '', '6', 8, 1, '2', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1448557801, 0, 1, '', '', '', '', '6', 9, 1, '2', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1448557801, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1448557801, 1, 1, '', '', '', '', '6', 11, 1, '2', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1448557801, 0, 1, '', '', '', '', '6', 12, 1, '2', 0, 0), 
('siteterms', 'page', 'siteterms', 'siteterms', 'Điều khoản sử dụng', '', 1448557801, 1, 1, '', '', '', '', '6', 13, 1, '2', 1, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Giới thiệu sản phẩm', '', 1448557801, 0, 1, '', '', '', '', '6', 14, 1, '2', 0, 0), 
('video-clip', 'page', 'video_clip', 'video-clip', 'video clip', 'Video clip', 1448566798, 1, 1, 'giaothanh', 'mobile_default', '', '', '6', 15, 1, '2', 1, 0), 
('tra-cuu-diem-thi', 'page', 'tra_cuu_diem_thi', 'tra-cuu-diem-thi', 'Tra cứu điểm thi', 'Tra cứu điểm thi', 1448632786, 1, 1, 'giaothanh', '', '', '', '6', 16, 1, '2', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_1`
--

DROP TABLE IF EXISTS `gt_vi_news_1`;
CREATE TABLE `gt_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_10`
--

DROP TABLE IF EXISTS `gt_vi_news_10`;
CREATE TABLE `gt_vi_news_10` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_11`
--

DROP TABLE IF EXISTS `gt_vi_news_11`;
CREATE TABLE `gt_vi_news_11` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_12`
--

DROP TABLE IF EXISTS `gt_vi_news_12`;
CREATE TABLE `gt_vi_news_12` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_13`
--

DROP TABLE IF EXISTS `gt_vi_news_13`;
CREATE TABLE `gt_vi_news_13` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_14`
--

DROP TABLE IF EXISTS `gt_vi_news_14`;
CREATE TABLE `gt_vi_news_14` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_15`
--

DROP TABLE IF EXISTS `gt_vi_news_15`;
CREATE TABLE `gt_vi_news_15` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_16`
--

DROP TABLE IF EXISTS `gt_vi_news_16`;
CREATE TABLE `gt_vi_news_16` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_17`
--

DROP TABLE IF EXISTS `gt_vi_news_17`;
CREATE TABLE `gt_vi_news_17` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_2`
--

DROP TABLE IF EXISTS `gt_vi_news_2`;
CREATE TABLE `gt_vi_news_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_8`
--

DROP TABLE IF EXISTS `gt_vi_news_8`;
CREATE TABLE `gt_vi_news_8` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_9`
--

DROP TABLE IF EXISTS `gt_vi_news_9`;
CREATE TABLE `gt_vi_news_9` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_admins`
--

DROP TABLE IF EXISTS `gt_vi_news_admins`;
CREATE TABLE `gt_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_admins`
--

INSERT INTO `gt_vi_news_admins` VALUES
(2, 0, 1, 1, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_block`
--

DROP TABLE IF EXISTS `gt_vi_news_block`;
CREATE TABLE `gt_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_block_cat`
--

DROP TABLE IF EXISTS `gt_vi_news_block_cat`;
CREATE TABLE `gt_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_block_cat`
--

INSERT INTO `gt_vi_news_block_cat` VALUES
(1, 1, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `gt_vi_news_bodyhtml_1`;
CREATE TABLE `gt_vi_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_bodytext`
--

DROP TABLE IF EXISTS `gt_vi_news_bodytext`;
CREATE TABLE `gt_vi_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_cat`
--

DROP TABLE IF EXISTS `gt_vi_news_cat`;
CREATE TABLE `gt_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=18  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_cat`
--

INSERT INTO `gt_vi_news_cat` VALUES
(1, 0, 'Nhà trường', '', 'nha-truong', '', '', '', 0, 1, 1, 0, 'viewcat_main_right', 3, '8,12,9', 1, 4, 2, 0, '', '', 1274986690, 1448753847, '6'), 
(2, 0, 'Hoạt động', '', 'hoat-dong', '', '', '', 0, 2, 5, 0, 'viewcat_page_new', 1, '17', 1, 4, 2, 0, '', '', 1274986705, 1448753921, '6'), 
(8, 1, 'Giới thiệu', '', 'gioi-thieu', '', '', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987105, 1448754600, '6'), 
(9, 1, 'Tổ chuyên môn', '', 'to-chuyen-mon', '', '', '', 0, 3, 4, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987212, 1448755624, '6'), 
(10, 0, 'Sự kiện', '', 'su-kien', '', '', '', 0, 3, 7, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987460, 1448753960, '6'), 
(11, 0, 'Phương pháp học tập', '', 'phuong-phap-hop-tap', '', '', '', 0, 4, 8, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987538, 1448754019, '6'), 
(12, 1, 'Ban giám hiệu', '', 'ban-giam-hieu', '', '', '', 0, 2, 3, 1, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', 1274987902, 1448754655, '6'), 
(13, 0, 'Tin học', '', 'tin-hoc', '', '', '', 0, 5, 9, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1448754041, 1448754041, '6'), 
(14, 0, 'Thư viện', '', 'thu-vien', '', '', '', 0, 6, 10, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1448754071, 1448754071, '6'), 
(15, 0, 'Thời khóa biểu', '', 'thoi-khoa-bieu', '', '', '', 0, 7, 11, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1448754095, 1448754095, '6'), 
(16, 0, 'Chung tay', '', 'chung-tay', '', '', '', 0, 8, 12, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1448754111, 1448754111, '6'), 
(17, 2, 'Chào cờ', '', 'chao-co', '', '', '', 0, 1, 6, 1, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1448755679, 1448755679, '6');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_config_post`
--

DROP TABLE IF EXISTS `gt_vi_news_config_post`;
CREATE TABLE `gt_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_config_post`
--

INSERT INTO `gt_vi_news_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(5, 0, 0, 0, 0), 
(10, 0, 0, 0, 0), 
(11, 0, 0, 0, 0), 
(12, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_logs`
--

DROP TABLE IF EXISTS `gt_vi_news_logs`;
CREATE TABLE `gt_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_rows`
--

DROP TABLE IF EXISTS `gt_vi_news_rows`;
CREATE TABLE `gt_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_sources`
--

DROP TABLE IF EXISTS `gt_vi_news_sources`;
CREATE TABLE `gt_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_sources`
--

INSERT INTO `gt_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(4, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 2, 1322685396, 1322685396);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_tags`
--

DROP TABLE IF EXISTS `gt_vi_news_tags`;
CREATE TABLE `gt_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=33  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_tags`
--

INSERT INTO `gt_vi_news_tags` VALUES
(1, 0, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 0, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 0, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 0, 'việt-nam', '', '', 'việt nam'), 
(5, 0, 'hoạt-động', '', '', 'hoạt động'), 
(6, 0, 'tin-tức', '', '', 'tin tức'), 
(7, 0, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 0, 'điện-tử', '', '', 'điện tử'), 
(9, 0, 'nukeviet', '', '', 'nukeviet'), 
(10, 0, 'nền-tảng', '', '', 'nền tảng'), 
(11, 0, 'xây-dựng', '', '', 'xây dựng'), 
(12, 1, 'quản-trị', '', '', 'quản trị'), 
(13, 1, 'nội-dung', '', '', 'nội dung'), 
(14, 1, 'sử-dụng', '', '', 'sử dụng'), 
(15, 1, 'khả-năng', '', '', 'khả năng'), 
(16, 1, 'tích-hợp', '', '', 'tích hợp'), 
(17, 1, 'ứng-dụng', '', '', 'ứng dụng'), 
(18, 0, 'vinades', '', '', 'vinades'), 
(19, 0, 'lập-trình-viên', '', '', 'lập trình viên'), 
(20, 0, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(21, 0, 'php', '', '', 'php'), 
(22, 0, 'mysql', '', '', 'mysql'), 
(23, 0, 'khai-trương', '', '', 'khai trương'), 
(24, 0, 'khuyến-mại', '', '', 'khuyến mại'), 
(25, 0, 'giảm-giá', '', '', 'giảm giá'), 
(26, 0, 'siêu-khuyến-mại', '', '', 'siêu khuyến mại'), 
(27, 0, 'webnhanh', '', '', 'webnhanh'), 
(28, 0, 'thiết-kế-website', '', '', 'thiết kế website'), 
(29, 0, 'giao-diện-web', '', '', 'giao diện web'), 
(30, 0, 'thiết-kế-web', '', '', 'thiết kế web'), 
(31, 0, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(32, 0, 'mã-nguồn-mở', '', '', 'mã nguồn mở');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_tags_id`
--

DROP TABLE IF EXISTS `gt_vi_news_tags_id`;
CREATE TABLE `gt_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_news_topics`
--

DROP TABLE IF EXISTS `gt_vi_news_topics`;
CREATE TABLE `gt_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_news_topics`
--

INSERT INTO `gt_vi_news_topics` VALUES
(1, 'NukeViet 3', 'NukeViet-3', '', 'NukeViet 3', 1, 'NukeViet 3', 1274990212, 1274990212);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_nha_truong_logs`
--

DROP TABLE IF EXISTS `gt_vi_nha_truong_logs`;
CREATE TABLE `gt_vi_nha_truong_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_page`
--

DROP TABLE IF EXISTS `gt_vi_page`;
CREATE TABLE `gt_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_page_config`
--

DROP TABLE IF EXISTS `gt_vi_page_config`;
CREATE TABLE `gt_vi_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_page_config`
--

INSERT INTO `gt_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_referer_stats`
--

DROP TABLE IF EXISTS `gt_vi_referer_stats`;
CREATE TABLE `gt_vi_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_searchkeys`
--

DROP TABLE IF EXISTS `gt_vi_searchkeys`;
CREATE TABLE `gt_vi_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_siteterms`
--

DROP TABLE IF EXISTS `gt_vi_siteterms`;
CREATE TABLE `gt_vi_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_siteterms`
--

INSERT INTO `gt_vi_siteterms` VALUES
(1, 'Chính sách bảo mật (Quyền riêng tư)', 'privacy', '', '', '', '<h2 style=\"text-align: justify;\">Điều 1: Thu thập thông tin</h2><h3 style=\"text-align: justify;\">1.1. Thu thập tự động:</h3><div style=\"text-align: justify;\">Như mọi website hiện đại khác, Chúng tôi sẽ thu thập địa chỉ IP và các thông tin web tiêu chuẩn khác của bạn như: loại trình duyệt, các trang bạn truy cập trong quá trình sử dụng dịch vụ, thông tin về máy tính &amp; thiết bị mạng v.v… cho mục đích phân tích thông tin phục vụ việc bảo mật và giữ an toàn cho hệ thống.</div><h3 style=\"text-align: justify;\">1.2. Thu thập từ các khai báo của chính bạn:</h3><div style=\"text-align: justify;\">Các thông tin do bạn khai báo cho chúng tôi trong quá trình làm việc như: đăng ký tài khoản, liên hệ với chúng tôi... cũng sẽ được chúng tôi lưu trữ phục vụ công việc chăm sóc khách hàng sau này.</div><h3 style=\"text-align: justify;\">1.3. Thu thập thông tin thông qua việc đặt cookies:</h3><p style=\"text-align: justify;\">Như mọi website hiện đại khác, khi bạn truy cập website, chúng tôi (hoặc các công cụ theo dõi hoặc thống kê hoạt động của website do các đối tác cung cấp) sẽ đặt một số File dữ liệu gọi là Cookies lên đĩa cứng hoặc bộ nhớ máy tính của bạn.</p><p style=\"text-align: justify;\">Một trong số những Cookies này có thể tồn tại lâu để thuận tiện cho bạn trong quá trình sử dụng, ví dụ như: lưu Email của bạn trong trang đăng nhập để bạn không phải nhập lại v.v…</p><h3 style=\"text-align: justify;\">1.4. Thu thập và lưu trữ thông tin trong quá khứ:</h3><p style=\"text-align: justify;\">Bạn có thể thay đổi thông tin cá nhân của mình bất kỳ lúc nào bằng cách sử dụng chức năng tương ứng. Tuy nhiên chúng tôi sẽ lưu lại những thông tin bị thay đổi để chống các hành vi xóa dấu vết gian lận.</p><h2 style=\"text-align: justify;\"><br  />Điều 2: Lưu trữ &amp; Bảo vệ thông tin</h2><div style=\"text-align: justify;\">Hầu hết các thông tin được thu thập sẽ được lưu trữ tại cơ sở dữ liệu của chúng tôi.<br  /><br  />Chúng tôi bảo vệ dữ liệu cá nhân của các bạn bằng các hình thức như: mật khẩu, tường lửa, mã hóa cùng các hình thức thích hợp khác và chỉ cấp phép việc truy cập và xử lý dữ liệu cho các đối tượng phù hợp, ví dụ chính bạn hoặc các nhân viên có trách nhiệm xử thông tin với bạn thông qua các bước xác định danh tính phù hợp.</div><h2 style=\"text-align: justify;\"><br  />Điều 3: Sử dụng thông tin</h2><p style=\"text-align: justify;\">Thông tin thu thập được sẽ được chúng tôi sử dụng để:</p><blockquote><p style=\"text-align: justify;\">o Cung cấp các dịch vụ hỗ trợ &amp; chăm sóc khách hàng.</p><p style=\"text-align: justify;\">o Thực hiện giao dịch thanh toán &amp; gửi các thông báo trong quá trình giao dịch.</p><p style=\"text-align: justify;\">o Xử lý khiếu nại, thu phí &amp; giải quyết sự cố.</p><p style=\"text-align: justify;\">o Ngăn chặn các hành vi có nguy cơ rủi ro, bị cấm hoặc bất hợp pháp và đảm bảo tuân thủ đúng chính sách “Thỏa thuận người dùng”.</p><p style=\"text-align: justify;\">o Đo đạc, tùy biến &amp; cải tiến dịch vụ, nội dung và hình thức của website.</p><p style=\"text-align: justify;\">o Gửi bạn các thông tin về chương trình Marketing, các thông báo &amp; chương trình khuyến mại.</p><p style=\"text-align: justify;\">o So sánh độ chính xác của thông tin cá nhân của bạn trong quá trình kiểm tra với bên thứ ba.</p></blockquote><h2 style=\"text-align: justify;\"><br  />Điều 4: Tiếp nhận thông tin từ các đối tác</h2><div style=\"text-align: justify;\">Khi sử dụng các công cụ giao dịch và thanh toán thông qua internet, chúng tôi có thể tiếp nhận thêm các thông tin về bạn như địa chỉ username, Email, số tài khoản ngân hàng... Chúng tôi kiểm tra những thông tin này với cơ sở dữ liệu người dùng của mình nhằm xác nhận rằng bạn có phải là khách hàng của chúng tôi hay không nhằm giúp việc thực hiện các dịch vụ cho bạn được thuận lợi.<br  /><br  />Các thông tin tiếp nhận được sẽ được chúng tôi bảo mật như những thông tin mà chúng tôi thu thập được trực tiếp từ bạn.</div><h2 style=\"text-align: justify;\"><br  />Điều 5: Chia sẻ thông tin với bên thứ ba</h2><p style=\"text-align: justify;\">Chúng tôi sẽ không chia sẻ thông tin cá nhân, thông tin tài chính... của bạn cho các bên thứ 3 trừ khi được sự đồng ý của chính bạn hoặc khi chúng tôi buộc phải tuân thủ theo các quy định pháp luật hoặc khi có yêu cầu từ cơ quan công quyền có thẩm quyền.</p><h2 style=\"text-align: justify;\"><br  />Điều 6: Thay đổi chính sách bảo mật</h2><p style=\"text-align: justify;\">Chính sách Bảo mật này có thể thay đổi theo thời gian. Chúng tôi sẽ không giảm quyền của bạn theo Chính sách Bảo mật này mà không có sự đồng ý rõ ràng của bạn. Chúng tôi sẽ đăng bất kỳ thay đổi Chính sách Bảo mật nào trên trang này và, nếu những thay đổi này quan trọng, chúng tôi sẽ cung cấp thông báo nổi bật hơn (bao gồm, đối với một số dịch vụ nhất định, thông báo bằng email về các thay đổi của Chính sách Bảo mật).<br  />&nbsp;</p><p style=\"text-align: right;\">Tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a></p>', '', 0, '4', '', 0, 1, 1, 1448557801, 1448557801, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_siteterms_config`
--

DROP TABLE IF EXISTS `gt_vi_siteterms_config`;
CREATE TABLE `gt_vi_siteterms_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_siteterms_config`
--

INSERT INTO `gt_vi_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_tra_cuu_diem_thi`
--

DROP TABLE IF EXISTS `gt_vi_tra_cuu_diem_thi`;
CREATE TABLE `gt_vi_tra_cuu_diem_thi` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_tra_cuu_diem_thi`
--

INSERT INTO `gt_vi_tra_cuu_diem_thi` VALUES
(1, 'Tra cứu điểm thi', 'tra-cuu-diem-thi', '', '', '', '<div class=\"input-group-search\"> <div class=\"input-group-btn-search\"><em class=\"fa fa-search fa-md\">Tra cứu</em></div> </div>', 'tra cứu', 1, '4', '', 0, 1, 1, 1448633054, 1448633054, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_tra_cuu_diem_thi_config`
--

DROP TABLE IF EXISTS `gt_vi_tra_cuu_diem_thi_config`;
CREATE TABLE `gt_vi_tra_cuu_diem_thi_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_tra_cuu_diem_thi_config`
--

INSERT INTO `gt_vi_tra_cuu_diem_thi_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_video_clip`
--

DROP TABLE IF EXISTS `gt_vi_video_clip`;
CREATE TABLE `gt_vi_video_clip` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `gt_vi_video_clip_config`
--

DROP TABLE IF EXISTS `gt_vi_video_clip_config`;
CREATE TABLE `gt_vi_video_clip_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_video_clip_config`
--

INSERT INTO `gt_vi_video_clip_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `gt_vi_voting`
--

DROP TABLE IF EXISTS `gt_vi_voting`;
CREATE TABLE `gt_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_voting`
--

INSERT INTO `gt_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Bạn quan tâm gì nhất ở mã nguồn mở?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `gt_vi_voting_rows`
--

DROP TABLE IF EXISTS `gt_vi_voting_rows`;
CREATE TABLE `gt_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gt_vi_voting_rows`
--

INSERT INTO `gt_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng xHTML, CSS và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);